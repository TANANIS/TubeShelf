(function (root, factory) {
  const api = factory();
  root.TubeShelfCore = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const VERSION = 1;
  const DEFAULT_GROUPS = [
    { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: [] },
    { id: "relax", name: "放鬆", icon: "sparkles", color: "#ff6b8a", channelIds: [] }
  ];

  const ICONS = {
    book: "M5 4.8A2.8 2.8 0 0 1 7.8 2H11v15H7.8A2.8 2.8 0 0 0 5 19.8V4.8Zm14 0A2.8 2.8 0 0 0 16.2 2H13v15h3.2a2.8 2.8 0 0 1 2.8 2.8V4.8Z",
    sparkles: "m12 2 1.1 3.4a5.5 5.5 0 0 0 3.5 3.5L20 10l-3.4 1.1a5.5 5.5 0 0 0-3.5 3.5L12 18l-1.1-3.4a5.5 5.5 0 0 0-3.5-3.5L4 10l3.4-1.1a5.5 5.5 0 0 0 3.5-3.5L12 2Zm7 14 .6 1.7a2.8 2.8 0 0 0 1.7 1.7l1.7.6-1.7.6a2.8 2.8 0 0 0-1.7 1.7L19 24l-.6-1.7a2.8 2.8 0 0 0-1.7-1.7L15 20l1.7-.6a2.8 2.8 0 0 0 1.7-1.7L19 16Z",
    game: "M8 7h8a6 6 0 0 1 5.7 7.9l-1.1 3.4a2.4 2.4 0 0 1-4.1.8L14.8 17H9.2l-1.7 2.1a2.4 2.4 0 0 1-4.1-.8l-1.1-3.4A6 6 0 0 1 8 7Zm0 3v2H6v2h2v2h2v-2h2v-2h-2v-2H8Zm8.5 2a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Zm2.5 3a1.2 1.2 0 1 0 0-2.4A1.2 1.2 0 0 0 19 15Z",
    music: "M18 3v13.1A4 4 0 1 1 16 13V7l-7 2v9.1A4 4 0 1 1 7 15V6l11-3Z",
    code: "m9 6-6 6 6 6 1.5-1.5L6 12l4.5-4.5L9 6Zm6 0-1.5 1.5L18 12l-4.5 4.5L15 18l6-6-6-6Z",
    star: "m12 2.8 2.8 5.7 6.3.9-4.6 4.5 1.1 6.3-5.6-3-5.6 3 1.1-6.3-4.6-4.5 6.3-.9L12 2.8Z"
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function defaultState() {
    return {
      version: VERSION,
      groups: clone(DEFAULT_GROUPS),
      channels: {},
      settings: { hideShorts: false, hideWatched: false, compactMode: false }
    };
  }

  function normalizeState(input) {
    const base = defaultState();
    if (!input || typeof input !== "object") return base;
    const channels = input.channels && typeof input.channels === "object" ? input.channels : {};
    const groups = Array.isArray(input.groups)
      ? input.groups
          .filter((group) => group && typeof group.name === "string")
          .map((group, index) => ({
            id: String(group.id || `group-${index + 1}`),
            name: group.name.trim().slice(0, 40) || `群組 ${index + 1}`,
            icon: ICONS[group.icon] ? group.icon : "star",
            color: /^#[0-9a-f]{6}$/i.test(group.color || "") ? group.color : "#7c5cff",
            channelIds: Array.isArray(group.channelIds)
              ? [...new Set(group.channelIds.map(String).filter((id) => channels[id]))]
              : []
          }))
      : base.groups;
    return {
      version: VERSION,
      groups,
      channels,
      settings: { ...base.settings, ...(input.settings || {}) }
    };
  }

  function channelKey(url) {
    if (!url || typeof url !== "string") return "";
    try {
      const parsed = new URL(url, "https://www.youtube.com");
      const path = parsed.pathname.replace(/\/$/, "");
      if (!/^\/(channel\/|@|c\/|user\/)/i.test(path)) return "";
      const parts = path.split("/").filter(Boolean);
      if (!parts.length) return "";
      const stableParts = parts[0].startsWith("@") ? [parts[0]] : parts.slice(0, 2);
      return `/${stableParts.join("/")}`.toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  function createId(name, usedIds) {
    const base = String(name || "group")
      .normalize("NFKD")
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fff]+/g, "-")
      .replace(/^-|-$/g, "") || "group";
    let id = base;
    let suffix = 2;
    while (usedIds.includes(id)) id = `${base}-${suffix++}`;
    return id;
  }

  function upsertChannels(state, incoming) {
    const next = normalizeState(state);
    for (const channel of incoming || []) {
      const id = channelKey(channel.url || channel.id);
      if (!id) continue;
      next.channels[id] = {
        id,
        name: String(channel.name || next.channels[id]?.name || id).trim().slice(0, 120),
        url: `https://www.youtube.com${id}`,
        avatar: typeof channel.avatar === "string" ? channel.avatar : next.channels[id]?.avatar || "",
        seenAt: Number(channel.seenAt) || Date.now()
      };
    }
    return next;
  }

  function groupForChannel(state, id) {
    return normalizeState(state).groups.filter((group) => group.channelIds.includes(id));
  }

  function iconSvg(name, color, size) {
    const path = ICONS[name] || ICONS.star;
    const px = Number(size) || 20;
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="${px}" height="${px}" fill="${color || "currentColor"}"><path d="${path}"/></svg>`;
  }

  return {
    VERSION,
    ICONS,
    DEFAULT_GROUPS,
    defaultState,
    normalizeState,
    channelKey,
    createId,
    upsertChannels,
    groupForChannel,
    iconSvg
  };
});
