(function () {
  "use strict";

  if (window.top !== window || document.getElementById("tubeshelf-launcher")) return;
  const Core = globalThis.TubeShelfCore;
  const STORAGE_KEY = "tubeShelfState";
  let state = Core.defaultState();
  let activeGroupId = "all";
  let scanTimer = null;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const pageKind = () => Core.youtubePageKind(location.href);
  const isSubscriptionsPage = () => pageKind() === "subscriptions";

  function openSubscriptionGroup(groupId) {
    if (!isSubscriptionsPage()) {
      location.assign(Core.subscriptionGroupUrl(groupId));
      return false;
    }
    activeGroupId = groupId || "all";
    renderGroups();
    renderIntegratedControls();
    applyFilters();
    return true;
  }

  async function readState() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    state = Core.normalizeState(result[STORAGE_KEY]);
    return state;
  }

  async function writeState(next) {
    state = Core.normalizeState(next);
    await chrome.storage.local.set({ [STORAGE_KEY]: state });
    renderGroups();
    renderIntegratedControls();
    applyFilters();
  }

  function makeShell() {
    const launcher = document.createElement("button");
    launcher.id = "tubeshelf-launcher";
    launcher.type = "button";
    launcher.title = "開啟 TubeShelf";
    launcher.setAttribute("aria-label", "開啟 TubeShelf 訂閱整理");
    launcher.innerHTML = `<svg viewBox="0 0 24 24" width="25" height="25" fill="none" aria-hidden="true"><path d="M5 5.8A2.8 2.8 0 0 1 7.8 3H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7.8A2.8 2.8 0 0 1 5 16.2V5.8Z" fill="currentColor" opacity=".3"/><path d="M4 7a2 2 0 0 1 2-2h10.5a1.5 1.5 0 0 1 0 3H8v8h8.5a1.5 1.5 0 0 1 0 3H6a2 2 0 0 1-2-2V7Z" fill="currentColor"/><path d="m11 10 5 3-5 3v-6Z" fill="currentColor"/></svg>`;

    const backdrop = document.createElement("div");
    backdrop.id = "tubeshelf-backdrop";
    const panel = document.createElement("aside");
    panel.id = "tubeshelf-panel";
    panel.setAttribute("aria-label", "TubeShelf");
    panel.innerHTML = `
      <header class="ts-panel-header">
        <div class="ts-logo"><svg viewBox="0 0 24 24" width="21" height="21" fill="white"><path d="M5 5.8A2.8 2.8 0 0 1 7.8 3H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7.8A2.8 2.8 0 0 1 5 16.2V5.8Zm6 4.2v6l5-3-5-3Z"/></svg></div>
        <div class="ts-title-wrap"><h2 class="ts-title">TubeShelf</h2><div class="ts-subtitle">你的 YouTube 訂閱書架</div></div>
        <button class="ts-icon-button" data-action="close" aria-label="關閉"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="m7.4 6 4.6 4.6L16.6 6 18 7.4 13.4 12l4.6 4.6-1.4 1.4-4.6-4.6L7.4 18 6 16.6l4.6-4.6L6 7.4 7.4 6Z"/></svg></button>
      </header>
      <nav class="ts-page-switch" aria-label="YouTube 內容來源">
        <button data-action="home" type="button"><span class="ts-page-icon">⌂</span><span><strong>首頁推薦</strong><small>YouTube 演算法</small></span></button>
        <button data-action="subscriptions" type="button"><span class="ts-page-icon">▦</span><span><strong>訂閱內容</strong><small>TubeShelf 群組</small></span></button>
      </nav>
      <p class="ts-page-note" id="ts-page-note"></p>
      <section class="ts-section">
        <div class="ts-section-label"><span>訂閱群組</span><span id="ts-channel-total"></span></div>
        <div class="ts-groups" id="ts-groups"></div>
      </section>
      <div class="ts-divider"></div>
      <section class="ts-section">
        <div class="ts-section-label"><span>畫面整理</span></div>
        <div class="ts-toggles">
          <label class="ts-toggle-row"><span>隱藏 Shorts</span><button class="ts-switch" data-setting="hideShorts" role="switch" aria-checked="false"></button></label>
          <label class="ts-toggle-row"><span>隱藏已觀看影片</span><button class="ts-switch" data-setting="hideWatched" role="switch" aria-checked="false"></button></label>
        </div>
      </section>
      <footer class="ts-panel-footer">
        <button class="ts-button" data-action="update-subscriptions">更新訂閱內容</button>
        <button class="ts-button ts-primary" data-action="manage">管理群組</button>
      </footer>`;

    const toast = document.createElement("div");
    toast.className = "ts-toast";
    toast.id = "ts-toast";
    document.documentElement.append(launcher, backdrop, panel, toast);

    launcher.addEventListener("click", openPanel);
    backdrop.addEventListener("click", closePanel);
    panel.addEventListener("click", onPanelClick);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closePanel();
    });
  }

  function openPanel() {
    $("#tubeshelf-backdrop")?.classList.add("ts-open");
    $("#tubeshelf-panel")?.classList.add("ts-open");
  }

  function closePanel() {
    $("#tubeshelf-backdrop")?.classList.remove("ts-open");
    $("#tubeshelf-panel")?.classList.remove("ts-open");
  }

  function toast(message) {
    const node = $("#ts-toast");
    if (!node) return;
    node.textContent = message;
    node.classList.add("ts-show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => node.classList.remove("ts-show"), 2200);
  }

  function renderGroups() {
    const host = $("#ts-groups");
    if (!host) return;
    const total = Object.keys(state.channels).length;
    $("#ts-channel-total").textContent = `${total} 個頻道`;
    const all = { id: "all", name: "全部訂閱", icon: "star", color: "#7c5cff", channelIds: Object.keys(state.channels) };
    const unfiled = { id: "unfiled", name: "未分類", icon: "sparkles", color: "#f0a44b", channelIds: Core.unfiledChannelIds(state) };
    const currentPage = pageKind();
    host.innerHTML = [all, unfiled, ...state.groups].map((group) => `
      <button class="ts-group ${currentPage === "subscriptions" && group.id === activeGroupId ? "ts-active" : ""}" data-group="${escapeHtml(group.id)}">
        <span class="ts-group-icon" style="color:${group.color};background:${group.color}20">${Core.iconSvg(group.icon, "currentColor", 18)}</span>
        <span><span class="ts-group-name">${escapeHtml(group.name)}</span><span class="ts-group-count" style="display:block">${group.id === "all" ? "目前已收集" : group.id === "unfiled" ? "等待整理" : "已分類"}</span></span>
        <span class="ts-pill">${group.channelIds.length}</span>
      </button>`).join("");
    $$('[data-action="home"], [data-action="subscriptions"]', $("#tubeshelf-panel")).forEach((button) => {
      const active = button.dataset.action === currentPage;
      button.classList.toggle("ts-active", active);
      button.setAttribute("aria-current", active ? "page" : "false");
    });
    const pageNote = $("#ts-page-note");
    if (pageNote) pageNote.textContent = currentPage === "home" ? "首頁由 YouTube 演算法決定，TubeShelf 不會隱藏或重排推薦內容。" : currentPage === "subscriptions" ? "只有訂閱內容會套用群組與畫面整理。" : "這個頁面不套用 TubeShelf 篩選；可前往訂閱內容使用群組。";
    $$('[data-setting]').forEach((button) => button.setAttribute("aria-checked", String(Boolean(state.settings[button.dataset.setting]))));
  }

  function integratedSignature() {
    return JSON.stringify({
      activeGroupId,
      groups: state.groups.map((group) => [group.id, group.name, group.icon, group.color, group.channelIds.length]),
      channels: Object.keys(state.channels).length,
      settings: state.settings,
      page: pageKind()
    });
  }

  function groupButtons(className) {
    const all = { id: "all", name: "全部", icon: "star", color: "#7c5cff", channelIds: Object.keys(state.channels) };
    const unfiled = { id: "unfiled", name: "未分類", icon: "sparkles", color: "#f0a44b", channelIds: Core.unfiledChannelIds(state) };
    return [all, unfiled, ...state.groups].map((group) => {
      if (className === "ts-guide-item") {
        return `<button class="ts-guide-item ${isSubscriptionsPage() && group.id === activeGroupId ? "ts-active" : ""}" data-ts-group="${escapeHtml(group.id)}" type="button"><span class="ts-guide-dot" style="color:${group.color};background:${group.color}20">${Core.iconSvg(group.icon, "currentColor", 15)}</span><span class="ts-guide-name">${escapeHtml(group.id === "all" ? "全部訂閱" : group.name)}</span><span class="ts-guide-count">${group.channelIds.length}</span></button>`;
      }
      return `<button class="ts-toolbar-chip ${isSubscriptionsPage() && group.id === activeGroupId ? "ts-active" : ""}" data-ts-group="${escapeHtml(group.id)}" type="button">${escapeHtml(group.name)} <small>${group.channelIds.length}</small></button>`;
    }).join("");
  }

  function mountIntegratedControls() {
    const guideSections = document.querySelector("ytd-guide-renderer #sections");
    if (guideSections && !document.getElementById("tubeshelf-guide-section")) {
      const section = document.createElement("section");
      section.id = "tubeshelf-guide-section";
      section.addEventListener("click", onIntegratedClick);
      guideSections.insertBefore(section, guideSections.children[1] || null);
    }

    if (!isSubscriptionsPage()) document.getElementById("tubeshelf-toolbar")?.remove();
    const browse = isSubscriptionsPage() ? document.querySelector('ytd-browse[page-subtype="subscriptions"]') : null;
    const primary = browse?.querySelector("#primary");
    if (primary && !document.getElementById("tubeshelf-toolbar")) {
      const toolbar = document.createElement("div");
      toolbar.id = "tubeshelf-toolbar";
      toolbar.addEventListener("click", onIntegratedClick);
      primary.insertBefore(toolbar, primary.firstChild);
    }
    document.documentElement.classList.toggle("tubeshelf-integrated", Boolean(document.getElementById("tubeshelf-guide-section") || document.getElementById("tubeshelf-toolbar")));
  }

  function renderIntegratedControls() {
    mountIntegratedControls();
    const signature = integratedSignature();
    const guide = document.getElementById("tubeshelf-guide-section");
    if (guide && guide.dataset.signature !== signature) {
      guide.dataset.signature = signature;
      guide.innerHTML = `<div class="ts-guide-heading"><span>TubeShelf 群組</span><span class="ts-guide-actions"><button data-ts-action="update-subscriptions" type="button" title="更新訂閱內容" aria-label="更新訂閱內容">↻</button><button data-ts-action="manage" type="button" title="管理群組" aria-label="管理 TubeShelf 群組">＋</button></span></div><div class="ts-guide-list">${groupButtons("ts-guide-item")}</div>`;
    }
    const toolbar = document.getElementById("tubeshelf-toolbar");
    if (toolbar && toolbar.dataset.signature !== signature) {
      toolbar.dataset.signature = signature;
      toolbar.innerHTML = `<div class="ts-toolbar-brand"><span>${Core.iconSvg("book", "currentColor", 15)}</span><strong>TubeShelf</strong></div><div class="ts-toolbar-groups">${groupButtons("ts-toolbar-chip")}</div><div class="ts-toolbar-tools"><button class="ts-toolbar-action" data-ts-setting="hideShorts" type="button" aria-pressed="${Boolean(state.settings.hideShorts)}" title="隱藏 Shorts">S</button><button class="ts-toolbar-action" data-ts-setting="hideWatched" type="button" aria-pressed="${Boolean(state.settings.hideWatched)}" title="隱藏已觀看影片">✓</button><button class="ts-toolbar-action" data-ts-action="update-subscriptions" type="button" title="更新訂閱內容">↻</button><button class="ts-toolbar-action" data-ts-action="manage" type="button" title="管理群組">⚙</button></div>`;
    }
  }

  async function onIntegratedClick(event) {
    const groupId = event.target.closest("[data-ts-group]")?.dataset.tsGroup;
    const action = event.target.closest("[data-ts-action]")?.dataset.tsAction;
    const setting = event.target.closest("[data-ts-setting]")?.dataset.tsSetting;
    if (groupId) {
      openSubscriptionGroup(groupId);
      return;
    }
    if (setting) {
      state.settings[setting] = !state.settings[setting];
      await writeState(state);
      return;
    }
    if (action === "manage") openPanel();
    if (action === "update-subscriptions") await startSubscriptionUpdate();
  }

  async function onPanelClick(event) {
    const action = event.target.closest("[data-action]")?.dataset.action;
    const groupId = event.target.closest("[data-group]")?.dataset.group;
    const setting = event.target.closest("[data-setting]")?.dataset.setting;
    if (action === "close") closePanel();
    if (action === "manage") chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" });
    if (action === "update-subscriptions") await startSubscriptionUpdate();
    if (action === "home") { location.assign("https://www.youtube.com/"); return; }
    if (action === "subscriptions") { openSubscriptionGroup("all"); return; }
    if (groupId) {
      if (openSubscriptionGroup(groupId)) toast(groupId === "all" ? "顯示全部訂閱" : groupId === "unfiled" ? "只顯示未分類頻道" : `只顯示「${state.groups.find((g) => g.id === groupId)?.name || "群組"}」`);
    }
    if (setting) {
      state.settings[setting] = !state.settings[setting];
      await writeState(state);
    }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  }

  function findChannelInCard(card) {
    const link = card.querySelector('a[href^="/@"], a[href^="/channel/"], a[href^="/c/"], a[href^="/user/"]');
    if (!link) return null;
    const id = Core.channelKey(link.href || link.getAttribute("href"));
    if (!id) return null;
    const nameNode = card.querySelector("#text, #channel-title, #channel-name, yt-formatted-string.ytd-channel-name");
    const avatar = card.querySelector("#avatar img, yt-img-shadow img")?.src || "";
    return { id, url: link.href, name: nameNode?.textContent?.trim() || link.textContent?.trim() || id, avatar };
  }

  async function startSubscriptionUpdate() {
    toast("即將更新全部訂閱內容…");
    try {
      const result = await chrome.runtime.sendMessage({ type: "START_SUBSCRIPTION_UPDATE" });
      if (!result?.ok) toast("無法啟動訂閱更新");
    } catch (_error) {
      toast("無法更新訂閱內容，請重新載入擴充套件");
    }
  }

  function renderScanProgress(count, done) {
    let overlay = document.getElementById("tubeshelf-scan-progress");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "tubeshelf-scan-progress";
      document.documentElement.append(overlay);
    }
    overlay.innerHTML = `<div class="ts-scan-card"><div class="ts-scan-symbol">${done ? "✓" : "↻"}</div><h2>${done ? "訂閱內容已更新" : "正在更新訂閱內容"}</h2><p>${done ? "這個分頁即將自動關閉。" : "TubeShelf 正在自動向下載入所有訂閱頻道，請暫時不要關閉這個分頁。"}</p><strong>${count}</strong><small>個頻道</small></div>`;
  }

  function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

  async function runSubscriptionUpdate() {
    const startedAt = Date.now();
    const found = new Map();
    let stableRounds = 0;
    let lastCount = -1;
    let lastHeight = -1;
    let reachedEnd = false;
    renderScanProgress(0, false);
    try {
      for (let readyRound = 0; readyRound < 30; readyRound++) {
        if (document.querySelector("ytd-channel-renderer")) break;
        await wait(500);
      }
      for (let round = 0; round < 240; round++) {
        document.querySelectorAll("ytd-channel-renderer").forEach((card) => {
          const channel = findChannelInCard(card);
          if (channel) found.set(channel.id, channel);
        });
        renderScanProgress(found.size, false);
        if (round % 4 === 0) chrome.runtime.sendMessage({ type: "SUBSCRIPTION_UPDATE_PROGRESS", count: found.size, startedAt }).catch(() => {});
        const height = document.documentElement.scrollHeight;
        const atBottom = window.scrollY + window.innerHeight >= height - 120;
        stableRounds = found.size === lastCount && height === lastHeight && atBottom ? stableRounds + 1 : 0;
        if (stableRounds >= 5) { reachedEnd = true; break; }
        lastCount = found.size;
        lastHeight = height;
        window.scrollTo(0, height);
        await wait(700);
      }
      if (!found.size) throw new Error("No channels found");
      if (!reachedEnd) throw new Error("Subscription list did not reach a stable end");
      await writeState(Core.replaceChannels(state, [...found.values()]));
      renderScanProgress(found.size, true);
      await chrome.runtime.sendMessage({ type: "SUBSCRIPTION_UPDATE_COMPLETE", count: found.size });
    } catch (_error) {
      renderScanProgress(found.size, false);
      const card = document.querySelector("#tubeshelf-scan-progress .ts-scan-card");
      if (card) card.innerHTML = `<div class="ts-scan-symbol">!</div><h2>更新未完成</h2><p>請確認 YouTube 的所有訂閱頻道頁能正常顯示，再重新執行。</p><strong>${found.size}</strong><small>個已找到頻道</small>`;
      chrome.runtime.sendMessage({ type: "SUBSCRIPTION_UPDATE_FAILED", count: found.size }).catch(() => {});
    }
  }

  function applyFilters() {
    if (!isSubscriptionsPage()) {
      $$('.tubeshelf-hidden').forEach((card) => card.classList.remove("tubeshelf-hidden"));
      return;
    }
    const group = ["all", "unfiled"].includes(activeGroupId) ? null : state.groups.find((item) => item.id === activeGroupId);
    const allowed = activeGroupId === "unfiled" ? new Set(Core.unfiledChannelIds(state)) : group ? new Set(group.channelIds) : null;
    const cards = $$('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-channel-renderer, ytd-compact-video-renderer, ytd-rich-section-renderer');
    for (const card of cards) {
      let hidden = false;
      const channel = findChannelInCard(card);
      if (allowed && (!channel || !allowed.has(channel.id))) hidden = true;
      if (state.settings.hideShorts) {
        const shortsLink = card.querySelector('a[href^="/shorts/"]');
        if (shortsLink || card.tagName.toLowerCase() === "ytd-rich-section-renderer") hidden = true;
      }
      if (state.settings.hideWatched) {
        const progress = card.querySelector("#progress, ytd-thumbnail-overlay-resume-playback-renderer");
        if (progress) hidden = true;
      }
      card.classList.toggle("tubeshelf-hidden", hidden);
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "OPEN_TUBESHELF") {
      if (["all", "unfiled"].includes(message.groupId) || state.groups.some((group) => group.id === message.groupId)) activeGroupId = message.groupId;
      if (message.groupId && !isSubscriptionsPage()) {
        location.assign(Core.subscriptionGroupUrl(activeGroupId));
        sendResponse({ ok: true, navigating: true });
        return;
      }
      renderGroups();
      applyFilters();
      openPanel();
      sendResponse({ ok: true });
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      state = Core.normalizeState(changes[STORAGE_KEY].newValue);
      renderGroups();
      renderIntegratedControls();
      applyFilters();
    }
  });

  const observer = new MutationObserver(() => {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(() => { renderGroups(); renderIntegratedControls(); applyFilters(); }, 250);
  });

  async function init() {
    makeShell();
    await readState();
    if (isSubscriptionsPage()) {
      const requestedGroup = new URLSearchParams(location.hash.replace(/^#/, "")).get("tubeshelf-group");
      if (["all", "unfiled"].includes(requestedGroup) || state.groups.some((group) => group.id === requestedGroup)) activeGroupId = requestedGroup;
    }
    renderGroups();
    renderIntegratedControls();
    applyFilters();
    observer.observe(document.body, { childList: true, subtree: true });
    if (location.pathname === "/feed/channels" && location.hash === "#tubeshelf-update-subscriptions") setTimeout(runSubscriptionUpdate, 900);
  }

  init();
})();
