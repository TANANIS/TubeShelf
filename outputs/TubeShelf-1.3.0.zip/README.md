# TubeShelf｜自己的 YouTube 訂閱整理器

TubeShelf 是一個可自行側載的 Chrome／Edge 擴充套件，功能概念來自 PocketTube，但程式與介面都是獨立製作。它不需要帳號、伺服器或付費方案，群組與頻道資料只保存在瀏覽器的 `chrome.storage.local`。

## 已完成的功能

- 把 TubeShelf 群組直接加入 YouTube 左側導覽列
- 在訂閱頁頂部直接切換群組、隱藏 Shorts／已觀看影片與更新訂閱內容
- 「更新訂閱內容」會自動開啟所有訂閱頻道頁、捲動載入到底並在完成後關閉
- 「自動整理群組（本機）」與訂閱更新完全分離，只分析尚未分類的頻道
- 自動整理會讀取公開頻道簡介與近期影片標題，在本機產生可勾選的分類建議
- 套用建議前不會修改群組，也不會覆寫既有的手動分類
- YouTube 尚未載入側欄時，才顯示右下角備援按鈕
- 從「所有訂閱內容」或訂閱動態頁掃描頻道
- 建立自訂群組，設定顏色與圖示
- 同一個頻道可放入多個群組
- 在 YouTube 頁面依群組篩選可見頻道／影片
- 隱藏 Shorts、隱藏已觀看影片
- 搜尋頻道、JSON 備份與還原
- 全程本機儲存，沒有追蹤、雲端 AI 或雲端同步

## 安裝到 Chrome

1. 開啟 `chrome://extensions/`。
2. 打開右上角「開發人員模式」。
3. 按「載入未封裝項目」。
4. 選擇本專案的 `extension` 資料夾。
5. 重新整理已經開啟的 YouTube 分頁。

Edge 的步驟相同，管理頁網址是 `edge://extensions/`。

## 第一次使用

1. 到 [YouTube 所有訂閱內容](https://www.youtube.com/feed/channels)。
2. 點瀏覽器工具列上的 TubeShelf，再按「更新訂閱內容」。TubeShelf 會開啟所有訂閱頻道頁、自動向下載入並在完成後關閉。
3. 點「管理群組」，可手動建立群組，或另外啟動「自動整理群組（本機）」取得分類建議。
4. 檢查並勾選建議後按「套用建議」；不確定的頻道會保留在待分類。
5. 回到 YouTube，直接從左側欄或訂閱頁頂部切換群組。

## 驗證

```powershell
node --test tests/shared.test.js
node --check extension/shared.js
node --check extension/content/content.js
node --check extension/popup/popup.js
node --check extension/dashboard/dashboard.js
```

## 限制

YouTube 是動態載入頁面，TubeShelf 會自動捲動「所有訂閱內容」直到清單穩定。自動整理使用本機文字規則，不確定或同分的頻道不會強制分類。YouTube 若日後改版其頁面資料結構，掃描與公開資料讀取方式可能需要跟著調整。

TubeShelf 與 PocketTube、YouTube 或 Google 沒有從屬或授權關係；這是供個人使用的獨立實作。
