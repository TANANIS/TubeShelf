(function () {
  "use strict";
  const Core = globalThis.TubeShelfCore;
  const STORAGE_KEY = "tubeShelfState";
  const PROFILE_VERSION = 4;
  const COLORS = ["#7c5cff", "#ff6b8a", "#2dbd9b", "#f0a44b", "#4a91ff", "#bc6fe8"];
  let state = Core.defaultState();
  let selectedGroupId = "all";
  let managingMembers = false;
  let query = "";
  let autoController = null;
  let profileController = null;
  let autoSuggestions = { groups: [], uncertain: [] };
  let workspaceLayoutFrame = 0;

  const api = location.protocol === "chrome-extension:" && globalThis.chrome?.storage?.local
    ? {
        load: async () => (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY],
        save: (value) => chrome.storage.local.set({ [STORAGE_KEY]: value }),
        open: (url) => chrome.tabs.create({ url })
      }
    : {
        load: async () => ({
          ...Core.defaultState(),
          channels: {
            "/@kurzgesagt": { id: "/@kurzgesagt", name: "Kurzgesagt – In a Nutshell", url: "https://www.youtube.com/@kurzgesagt" },
            "/@veritasium": { id: "/@veritasium", name: "Veritasium", url: "https://www.youtube.com/@veritasium" },
            "/@lofigirl": { id: "/@lofigirl", name: "Lofi Girl", url: "https://www.youtube.com/@lofigirl" },
            "/@gamemakers": { id: "/@gamemakers", name: "Game Maker's Toolkit", url: "https://www.youtube.com/@gamemakers" },
            "/@twreporter": { id: "/@twreporter", name: "報導者 The Reporter", url: "https://www.youtube.com/@twreporter" }
          },
          groups: [
            { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: ["/@kurzgesagt", "/@veritasium"] },
            { id: "relax", name: "放鬆", icon: "music", color: "#ff6b8a", channelIds: [] }
          ]
        }),
        save: async () => {}, open: (url) => window.open(url, "_blank")
      };

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));

  async function save(next, message) {
    state = Core.normalizeState(next);
    await api.save(state);
    render();
    if (message) toast(message);
  }

  function render() {
    const channels = Object.values(state.channels);
    const filed = new Set(state.groups.flatMap((group) => group.channelIds)).size;
    const progress = channels.length ? Math.round((filed / channels.length) * 100) : 0;
    $("stat-channels").textContent = channels.length;
    $("stat-groups").textContent = state.groups.length;
    $("stat-progress").textContent = `${progress}%`;
    $("stat-unfiled").textContent = channels.length ? `${channels.length - filed} 個頻道尚未分類` : "尚無待分類頻道";
    renderGroups();
    renderChannels();
    document.querySelectorAll("[data-setting]").forEach((input) => { input.checked = Boolean(state.settings[input.dataset.setting]); });
    $("open-home").hidden = Boolean(state.settings.blockHome);
  }

  function scheduleWorkspaceLayout() {
    cancelAnimationFrame(workspaceLayoutFrame);
    workspaceLayoutFrame = requestAnimationFrame(() => {
      const groupPane = document.querySelector(".group-pane");
      const channelPane = document.querySelector(".channel-pane");
      const channelList = $("channel-list");
      const toolbar = channelPane?.querySelector(".channel-toolbar");
      const manager = $("member-manager");
      if (!groupPane || !channelPane || !channelList || !toolbar) return;
      if (matchMedia("(max-width: 680px)").matches) {
        channelPane.style.height = "";
        channelList.style.maxHeight = "";
        return;
      }
      channelPane.style.height = "auto";
      channelList.style.maxHeight = "none";
      const fixedHeight = toolbar.offsetHeight + (manager.hidden ? 0 : manager.offsetHeight) + 2;
      const naturalHeight = fixedHeight + channelList.scrollHeight;
      const paneTop = Math.max(0, channelPane.getBoundingClientRect().top);
      const viewportCapacity = Math.max(360, window.innerHeight - paneTop - 24);
      const availableHeight = Math.max(groupPane.offsetHeight, viewportCapacity);
      const targetHeight = Math.min(naturalHeight, availableHeight);
      channelPane.style.height = `${Math.ceil(targetHeight)}px`;
      channelList.style.maxHeight = `${Math.max(180, Math.floor(targetHeight - fixedHeight))}px`;
    });
  }

  function renderGroups() {
    const items = [
      { id: "all", name: "全部頻道", icon: "star", color: "#8c8497", channelIds: Object.keys(state.channels), systemLabel: "所有已收集頻道" },
      { id: "unfiled", name: "未分類", icon: "sparkles", color: "#f0a44b", channelIds: Core.unfiledChannelIds(state), systemLabel: "等待手動或自動整理" },
      ...state.groups
    ];
    $("group-list").innerHTML = items.map((group) => `<button class="group-item ${selectedGroupId === group.id ? "active" : ""}" data-group="${escapeHtml(group.id)}" type="button">
      <span class="group-icon" style="color:${group.color};background:${group.color}1b">${Core.iconSvg(group.icon, "currentColor", 17)}</span>
      <span class="group-copy"><strong>${escapeHtml(group.name)}</strong><small>${escapeHtml(group.systemLabel || "自訂群組")}</small></span>
      <span class="group-number">${group.channelIds.length}</span>
    </button>`).join("");
  }

  function renderChannels() {
    const isUnfiled = selectedGroupId === "unfiled";
    const selected = state.groups.find((group) => group.id === selectedGroupId);
    const unfiled = new Set(Core.unfiledChannelIds(state));
    const selectedIds = selected && !managingMembers ? new Set(selected.channelIds) : null;
    $("selected-title").textContent = managingMembers && selected ? `管理「${selected.name}」成員` : isUnfiled ? "未分類" : selected?.name || "全部頻道";
    $("selected-subtitle").textContent = managingMembers && selected ? "查看全部頻道並用開關加入或移出；也可以一次處理目前搜尋結果" : isUnfiled ? "等待手動加入群組，或使用本機自動整理" : selected ? "只顯示這個群組的頻道；點擊頻道可調整分類" : "查看所有已從 YouTube 收集的頻道";
    $("group-actions").hidden = !selected;
    $("manage-members").textContent = managingMembers ? "完成管理" : "管理成員";
    $("member-manager").hidden = !managingMembers || !selected;
    $("member-count").textContent = selected ? `${selected.channelIds.length} / ${Object.keys(state.channels).length}` : "0 / 0";
    $("search").placeholder = managingMembers ? "搜尋全部頻道" : "搜尋這個群組";
    if (!profileController) $("refresh-profiles").textContent = selected ? "更新此群組資料" : isUnfiled ? "更新未分類資料" : "更新全部頻道資料";
    const channels = Object.values(state.channels)
      .filter((channel) => !isUnfiled || unfiled.has(channel.id))
      .filter((channel) => !selectedIds || selectedIds.has(channel.id))
      .filter((channel) => !query || channel.name.toLowerCase().includes(query) || channel.id.includes(query))
      .sort((a, b) => {
        if (managingMembers && selected) {
          const membershipOrder = Number(selected.channelIds.includes(b.id)) - Number(selected.channelIds.includes(a.id));
          if (membershipOrder) return membershipOrder;
        }
        return a.name.localeCompare(b.name, "zh-Hant");
      });
    if (managingMembers && selected) {
      const visibleMemberCount = channels.filter((channel) => selected.channelIds.includes(channel.id)).length;
      const visibleMissingCount = channels.length - visibleMemberCount;
      $("add-filtered").textContent = `加入目前結果（${visibleMissingCount}）`;
      $("remove-filtered").textContent = `移出目前結果（${visibleMemberCount}）`;
      $("add-filtered").disabled = visibleMissingCount === 0;
      $("remove-filtered").disabled = visibleMemberCount === 0;
    }
    if (!channels.length) {
      const emptyGroup = selected || isUnfiled;
      $("channel-list").innerHTML = `<div class="empty-state"><div class="empty-icon">${Core.iconSvg(query ? "star" : "book", "currentColor", 25)}</div><strong>${query ? "找不到符合的頻道" : emptyGroup ? "這裡目前沒有頻道" : "書架還是空的"}</strong><p>${query ? "換個關鍵字再試一次。" : emptyGroup ? "可從頻道詳細資料調整群組，或執行本機自動整理。" : "按「更新訂閱內容」，TubeShelf 就會自動載入全部 YouTube 訂閱頻道。"}</p></div>`;
      scheduleWorkspaceLayout();
      return;
    }
    $("channel-list").innerHTML = channels.map((channel) => {
      const memberships = Core.groupForChannel(state, channel.id);
      const avatar = channel.avatar ? `<img src="${escapeHtml(channel.avatar)}" alt="" referrerpolicy="no-referrer" />` : escapeHtml(channel.name.slice(0, 1).toUpperCase());
      const chips = memberships.length ? `${memberships.slice(0, 1).map((group) => `<span class="chip" style="color:${group.color};background:${group.color}17">${escapeHtml(group.name)}</span>`).join("")}${memberships.length > 1 ? `<span class="chip">+${memberships.length - 1}</span>` : ""}` : '<span class="unfiled">尚未分類</span>';
      const control = selected
        ? `<button class="member-toggle" data-channel="${escapeHtml(channel.id)}" role="switch" aria-label="${escapeHtml(channel.name)} 加入 ${escapeHtml(selected.name)}" aria-checked="${selected.channelIds.includes(channel.id)}"></button>`
        : isUnfiled ? `<span class="card-status">待</span>` : `<a class="channel-open" href="${escapeHtml(channel.url)}" target="_blank" rel="noreferrer" aria-label="在 YouTube 開啟 ${escapeHtml(channel.name)}">↗</a>`;
      return `<article class="channel-card ${selected?.channelIds.includes(channel.id) ? "is-member" : ""}" data-channel-row="${escapeHtml(channel.id)}" tabindex="0" aria-label="檢視頻道 ${escapeHtml(channel.name)}"><div class="channel-main"><span class="avatar">${avatar}</span><span class="channel-name">${escapeHtml(channel.name)}</span><span class="channel-url">${escapeHtml(channel.id)}</span></div><div class="chips">${chips}</div>${control}</article>`;
    }).join("");
    scheduleWorkspaceLayout();
  }

  function openChannelDetail(channelId) {
    const channel = state.channels[channelId];
    if (!channel) return;
    const memberships = Core.groupForChannel(state, channel.id);
    const suggestion = Core.classifyChannel(channel);
    const avatar = channel.avatar ? `<img src="${escapeHtml(channel.avatar)}" alt="" referrerpolicy="no-referrer" />` : escapeHtml(channel.name.slice(0, 1).toUpperCase());
    $("detail-avatar").innerHTML = avatar;
    $("detail-name").textContent = channel.name;
    $("detail-id").textContent = channel.id;
    $("detail-open").dataset.url = channel.url;
    $("detail-open").dataset.channelId = channel.id;
    $("detail-groups").innerHTML = state.groups.length
      ? state.groups.map((group) => `<label class="detail-group-option"><input type="checkbox" data-detail-group="${escapeHtml(group.id)}" data-detail-channel="${escapeHtml(channel.id)}" ${group.channelIds.includes(channel.id) ? "checked" : ""}><span>${escapeHtml(group.name)}</span></label>`).join("")
      : '<span class="detail-empty">尚未建立群組</span>';
    const confidenceNames = { high: "高信心", medium: "中等信心", low: "低信心" };
    $("detail-suggestion").innerHTML = suggestion
      ? `<strong>${escapeHtml(suggestion.name)}</strong><span class="confidence">${confidenceNames[suggestion.confidence] || "建議"}</span>`
      : '<span class="detail-empty">目前沒有明確建議</span>';
    $("detail-reasons").textContent = suggestion?.reasons?.length ? `依據：${suggestion.reasons.join("、")}` : "沒有足夠且唯一的主題訊號";
    const matchesCurrent = suggestion && memberships.some((group) => group.name === suggestion.name);
    $("detail-suggestion-card").classList.toggle("detail-mismatch", Boolean(suggestion && memberships.length && !matchesCurrent));
    $("detail-description").textContent = channel.description || "尚未取得頻道簡介；執行自動整理後會補齊公開資料。";
    $("detail-titles").innerHTML = channel.recentTitles?.length
      ? channel.recentTitles.map((title) => `<li>${escapeHtml(title)}</li>`).join("")
      : '<li class="detail-empty">尚未取得近期影片標題</li>';
    if (!$("channel-dialog").open) $("channel-dialog").showModal();
  }

  function openDialog(group) {
    $("dialog-title").textContent = group ? "編輯群組" : "新增群組";
    $("group-id").value = group?.id || "";
    $("group-name").value = group?.name || "";
    $("icon-options").innerHTML = Object.keys(Core.ICONS).map((icon, index) => `<label class="option-radio"><input type="radio" name="icon" value="${icon}" ${(group?.icon || "book") === icon || (!group && index === 0) ? "checked" : ""}><span>${Core.iconSvg(icon, "currentColor", 17)}</span></label>`).join("");
    $("color-options").innerHTML = COLORS.map((color, index) => `<label class="option-radio"><input type="radio" name="color" value="${color}" ${(group?.color || COLORS[0]) === color || (!group && index === 0) ? "checked" : ""}><span style="background:${color}"></span></label>`).join("");
    $("delete-group").hidden = !group;
    $("group-dialog").showModal();
    setTimeout(() => $("group-name").focus(), 30);
  }

  function toast(message) {
    const node = $("toast");
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => node.classList.remove("show"), 2200);
  }

  function extractJsonObject(source, start) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let index = start; index < source.length; index += 1) {
      const char = source[index];
      if (inString) {
        if (escaped) escaped = false;
        else if (char === "\\") escaped = true;
        else if (char === '"') inString = false;
        continue;
      }
      if (char === '"') { inString = true; continue; }
      if (char === "{") depth += 1;
      if (char === "}" && --depth === 0) return source.slice(start, index + 1);
    }
    return "";
  }

  function parseInitialData(documentNode) {
    const markers = ["var ytInitialData =", 'window["ytInitialData"] =', "ytInitialData ="];
    for (const script of documentNode.scripts) {
      const source = script.textContent || "";
      for (const marker of markers) {
        const markerIndex = source.indexOf(marker);
        if (markerIndex < 0) continue;
        const start = source.indexOf("{", markerIndex + marker.length);
        if (start < 0) continue;
        try { return JSON.parse(extractJsonObject(source, start)); }
        catch (_error) {}
      }
    }
    return null;
  }

  function collectVideoTitles(initialData) {
    return Core.collectRecentVideoTitles(initialData);
  }

  function collectChannelMetadata(initialData) {
    let metadata = null;
    function visit(node) {
      if (!node || metadata) return;
      if (Array.isArray(node)) { node.forEach(visit); return; }
      if (typeof node !== "object") return;
      if (node.channelMetadataRenderer) { metadata = node.channelMetadataRenderer; return; }
      Object.values(node).forEach(visit);
    }
    visit(initialData);
    return {
      description: String(metadata?.description || "").trim(),
      keywords: String(metadata?.keywords || "").trim(),
      channelId: String(metadata?.externalId || "").trim()
    };
  }

  function extractChannelId(source, page, metadataId) {
    if (metadataId) return metadataId;
    const metaId = page.querySelector('meta[itemprop="channelId"]')?.content?.trim();
    if (metaId) return metaId;
    return source.match(/"(?:externalId|channelId)":"(UC[\w-]+)"/)?.[1] || "";
  }

  async function fetchChannelProfile(channel, signal) {
    const response = await fetch(`${channel.url.replace(/\/$/, "")}/videos`, { credentials: "include", cache: "no-store", signal });
    if (!response.ok) throw new Error(`YouTube ${response.status}`);
    const source = await response.text();
    const page = new DOMParser().parseFromString(source, "text/html");
    const initialData = parseInitialData(page);
    const metadata = collectChannelMetadata(initialData);
    const channelId = extractChannelId(source, page, metadata.channelId);
    const description = metadata.description || page.querySelector('meta[name="description"], meta[property="og:description"]')?.content?.trim() || "";
    const keywords = Core.sanitizeChannelKeywords(metadata.keywords);
    let recentTitles = collectVideoTitles(initialData);
    if (!recentTitles.length && channelId) {
      try {
        const feedResponse = await fetch(`https://www.youtube.com/feeds/videos.xml?channel_id=${encodeURIComponent(channelId)}`, { cache: "no-store", signal });
        if (feedResponse.ok) {
          const feed = new DOMParser().parseFromString(await feedResponse.text(), "application/xml");
          recentTitles = [...feed.getElementsByTagName("entry")].map((entry) => entry.getElementsByTagName("title")[0]?.textContent?.trim()).filter(Boolean).slice(0, 20);
        }
      } catch (error) {
        if (error.name === "AbortError") throw error;
      }
    }
    return { description: Core.sanitizeDescription(description), keywords, channelId, recentTitles, profiledAt: Date.now(), profileVersion: PROFILE_VERSION };
  }

  function profileScopeChannels() {
    const selected = state.groups.find((group) => group.id === selectedGroupId);
    if (selected) return selected.channelIds.map((id) => state.channels[id]).filter(Boolean);
    if (selectedGroupId === "unfiled") {
      const ids = new Set(Core.unfiledChannelIds(state));
      return Object.values(state.channels).filter((channel) => ids.has(channel.id));
    }
    return Object.values(state.channels);
  }

  async function refreshProfiles() {
    if (profileController) { profileController.abort(); return; }
    const targets = profileScopeChannels();
    if (!targets.length) { toast("目前沒有頻道可更新"); return; }
    if (targets.length >= 50 && !confirm(`要更新 ${targets.length} 個頻道的公開資料嗎？可以隨時按「停止更新」。`)) return;
    profileController = new AbortController();
    let cursor = 0;
    let done = 0;
    let failed = 0;
    let withTitles = 0;
    const button = $("refresh-profiles");
    button.classList.add("danger");
    button.textContent = `停止更新 0 / ${targets.length}`;
    const controller = profileController;
    try {
      const workers = Array.from({ length: Math.min(3, targets.length) }, async () => {
        while (cursor < targets.length && !controller.signal.aborted) {
          const channel = targets[cursor++];
          try {
            Object.assign(state.channels[channel.id], await fetchChannelProfile(channel, controller.signal));
            if (state.channels[channel.id].recentTitles?.length) withTitles += 1;
          } catch (error) {
            if (error.name !== "AbortError") failed += 1;
          }
          done += 1;
          button.textContent = `停止更新 ${done} / ${targets.length}`;
        }
      });
      await Promise.all(workers);
      await api.save(state);
      render();
      toast(controller.signal.aborted ? `已停止；保留 ${done} 個更新結果` : `更新完成：${withTitles} 個取得影片標題${failed ? `，${failed} 個讀取失敗` : ""}`);
    } finally {
      if (profileController === controller) profileController = null;
      button.classList.remove("danger");
      renderChannels();
    }
  }

  function showAutoStep(name) {
    ["intro", "progress", "results"].forEach((step) => { $(`auto-${step}`).hidden = step !== name; });
    $("auto-start").hidden = name !== "intro";
    $("auto-apply").hidden = name !== "results";
    $("auto-cancel").textContent = name === "results" ? "關閉" : "取消";
  }

  function updateAutoProgress(done, total, channelName) {
    const percent = total ? Math.round((done / total) * 100) : 100;
    $("auto-percent").textContent = `${percent}%`;
    $("auto-progress-bar").style.width = `${percent}%`;
    $("auto-progress-title").textContent = done < total ? "正在取得頻道分類線索" : "正在本機產生分類建議";
    $("auto-progress-copy").textContent = done < total ? `${done} / ${total}　${channelName || ""}` : "所有文字只在這台裝置上分析。";
  }

  function renderAutoResults() {
    const suggestedCount = autoSuggestions.groups.reduce((sum, group) => sum + group.channelIds.length, 0);
    $("auto-result-count").textContent = suggestedCount;
    $("auto-uncertain-count").textContent = autoSuggestions.uncertain.length ? `${autoSuggestions.uncertain.length} 個頻道資訊不足，保留待分類` : "所有待分類頻道都有建議";
    $("auto-suggestion-list").innerHTML = autoSuggestions.groups.length
      ? autoSuggestions.groups.map((group) => {
          const sample = group.channels.slice(0, 4).map((channel) => channel.name).join("、");
          const reasons = [...new Set(group.channels.flatMap((channel) => channel.reasons))].slice(0, 3).join("、");
          return `<label class="suggestion-card"><input type="checkbox" data-auto-group="${escapeHtml(group.groupId)}" checked><span class="suggestion-icon" style="color:${group.color};background:${group.color}1b">${Core.iconSvg(group.icon, "currentColor", 17)}</span><span class="suggestion-copy"><strong>${escapeHtml(group.name)}</strong><small>${escapeHtml(sample)}${group.channels.length > 4 ? "…" : ""}${reasons ? `　依據：${escapeHtml(reasons)}` : ""}</small></span><span class="suggestion-count">${group.channelIds.length}</span></label>`;
        }).join("")
      : `<div class="empty-state"><strong>目前沒有足夠明確的分類建議</strong><p>既有群組不會受到影響；資訊不足的頻道會繼續留在待分類。</p></div>`;
    $("auto-apply").disabled = !autoSuggestions.groups.length;
    showAutoStep("results");
  }

  async function startAutoOrganize() {
    const unfiledIds = new Set(Core.unfiledChannelIds(state));
    const unfiled = Object.values(state.channels).filter((channel) => unfiledIds.has(channel.id));
    if (!unfiled.length) { toast(Object.keys(state.channels).length ? "目前沒有尚未分類的頻道" : "請先更新訂閱內容"); return; }
    autoController = new AbortController();
    showAutoStep("progress");
    const staleBefore = Date.now() - 30 * 24 * 60 * 60 * 1000;
    const targets = unfiled.filter((channel) => channel.profileVersion !== PROFILE_VERSION || !channel.profiledAt || channel.profiledAt < staleBefore);
    let cursor = 0;
    let done = 0;
    let failed = 0;
    updateAutoProgress(0, targets.length, "");
    try {
      const workers = Array.from({ length: Math.min(3, targets.length) }, async () => {
        while (cursor < targets.length && !autoController.signal.aborted) {
          const channel = targets[cursor++];
          try { Object.assign(state.channels[channel.id], await fetchChannelProfile(channel, autoController.signal)); }
          catch (error) { if (error.name !== "AbortError") failed += 1; }
          done += 1;
          updateAutoProgress(done, targets.length, channel.name);
        }
      });
      await Promise.all(workers);
      if (autoController.signal.aborted) { await api.save(state); return; }
      await api.save(state);
      updateAutoProgress(targets.length, targets.length, "");
      autoSuggestions = Core.buildAutoGroupSuggestions(state);
      renderAutoResults();
      if (failed) toast(`${failed} 個頻道暫時無法讀取，已用現有資料分析`);
    } finally {
      autoController = null;
    }
  }

  function closeAutoDialog() {
    autoController?.abort();
    $("auto-dialog").close();
  }

  document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item === button));
    const settings = button.dataset.view === "settings";
    $("library-view").hidden = settings;
    $("settings-view").hidden = !settings;
    document.querySelector(".page-header h1").textContent = settings ? "偏好設定" : "訂閱書架";
    document.querySelector(".page-header > div > p:last-child").textContent = settings ? "控制 YouTube 頁面上的顯示方式與本機資料。" : "把頻道放進不同群組，回到 YouTube 就能一鍵篩選。";
  }));
  $("group-list").addEventListener("click", (event) => { const id = event.target.closest("[data-group]")?.dataset.group; if (id) { selectedGroupId = id; managingMembers = false; query = ""; $("search").value = ""; render(); } });
  $("channel-list").addEventListener("click", async (event) => {
    const id = event.target.closest("[data-channel]")?.dataset.channel;
    const group = state.groups.find((item) => item.id === selectedGroupId);
    if (id && group) {
      group.channelIds = group.channelIds.includes(id) ? group.channelIds.filter((item) => item !== id) : [...group.channelIds, id];
      await save(state, group.channelIds.includes(id) ? `已加入「${group.name}」` : `已移出「${group.name}」`);
      return;
    }
    if (event.target.closest("a, button, input, select")) return;
    const rowId = event.target.closest("[data-channel-row]")?.dataset.channelRow;
    if (rowId) openChannelDetail(rowId);
  });
  $("channel-list").addEventListener("keydown", (event) => {
    if (!["Enter", " "].includes(event.key)) return;
    const row = event.target.closest("[data-channel-row]");
    if (event.target !== row) return;
    const rowId = row?.dataset.channelRow;
    if (!rowId) return;
    event.preventDefault();
    openChannelDetail(rowId);
  });
  $("search").addEventListener("input", (event) => { query = event.target.value.trim().toLowerCase(); renderChannels(); });
  $("refresh-profiles").addEventListener("click", refreshProfiles);
  $("edit-selected-group").addEventListener("click", () => {
    const group = state.groups.find((item) => item.id === selectedGroupId);
    if (group) openDialog(group);
  });
  $("manage-members").addEventListener("click", () => { managingMembers = !managingMembers; renderChannels(); });
  async function updateFilteredMembership(add) {
    const group = state.groups.find((item) => item.id === selectedGroupId);
    if (!group || !managingMembers) return;
    const matchingIds = Object.values(state.channels)
      .filter((channel) => !query || channel.name.toLowerCase().includes(query) || channel.id.includes(query))
      .map((channel) => channel.id);
    const existing = new Set(group.channelIds);
    const changedIds = matchingIds.filter((id) => add ? !existing.has(id) : existing.has(id));
    if (!changedIds.length) { toast(add ? "目前結果都已在群組中" : "目前結果都不在群組中"); return; }
    if ((!add || changedIds.length >= 20) && !confirm(`要把 ${changedIds.length} 個頻道${add ? "加入" : "移出"}「${group.name}」嗎？`)) return;
    const changed = new Set(changedIds);
    group.channelIds = add ? [...group.channelIds, ...changedIds] : group.channelIds.filter((id) => !changed.has(id));
    await save(state, add ? `已加入 ${changedIds.length} 個頻道` : `已移出 ${changedIds.length} 個頻道`);
  }
  $("add-filtered").addEventListener("click", () => updateFilteredMembership(true));
  $("remove-filtered").addEventListener("click", () => updateFilteredMembership(false));
  $("detail-close").addEventListener("click", () => $("channel-dialog").close());
  $("detail-refresh").addEventListener("click", async () => {
    const channelId = $("detail-open").dataset.channelId;
    const channel = state.channels[channelId];
    if (!channel) return;
    const button = $("detail-refresh");
    button.disabled = true;
    button.textContent = "更新中…";
    try {
      Object.assign(channel, await fetchChannelProfile(channel));
      await api.save(state);
      render();
      openChannelDetail(channelId);
      toast(channel.recentTitles?.length ? `已取得 ${channel.recentTitles.length} 部近期影片` : "已更新資料，但頻道沒有可讀取的近期影片");
    } catch (_error) {
      toast("暫時無法更新這個頻道");
    } finally {
      button.disabled = false;
      button.textContent = "更新資料";
    }
  });
  $("detail-open").addEventListener("click", (event) => api.open(event.currentTarget.dataset.url));
  $("detail-groups").addEventListener("change", async (event) => {
    const input = event.target.closest("[data-detail-group]");
    if (!input) return;
    const group = state.groups.find((item) => item.id === input.dataset.detailGroup);
    const channelId = input.dataset.detailChannel;
    if (!group || !state.channels[channelId]) return;
    group.channelIds = input.checked ? [...new Set([...group.channelIds, channelId])] : group.channelIds.filter((id) => id !== channelId);
    await save(state, input.checked ? `已加入「${group.name}」` : `已移出「${group.name}」`);
    openChannelDetail(channelId);
  });
  [$("new-group"), $("mini-add")].forEach((button) => button.addEventListener("click", () => openDialog()));
  document.querySelectorAll("[data-dialog-close]").forEach((button) => button.addEventListener("click", () => $("group-dialog").close()));
  $("group-list").addEventListener("dblclick", (event) => { const id = event.target.closest("[data-group]")?.dataset.group; const group = state.groups.find((item) => item.id === id); if (group) openDialog(group); });
  $("group-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = $("group-name").value.trim();
    if (!name) return;
    const id = $("group-id").value;
    const icon = new FormData(event.currentTarget).get("icon") || "star";
    const color = new FormData(event.currentTarget).get("color") || COLORS[0];
    if (id) {
      const group = state.groups.find((item) => item.id === id);
      if (group) Object.assign(group, { name, icon, color });
    } else {
      state.groups.push({ id: Core.createId(name, state.groups.map((item) => item.id)), name, icon, color, channelIds: [] });
    }
    $("group-dialog").close();
    await save(state, id ? "群組已更新" : "群組已建立");
  });
  $("delete-group").addEventListener("click", async () => {
    const id = $("group-id").value;
    const group = state.groups.find((item) => item.id === id);
    if (!group || !confirm(`要刪除「${group.name}」嗎？其中 ${group.channelIds.length} 個頻道只會回到未分類，不會取消訂閱。`)) return;
    state.groups = state.groups.filter((item) => item.id !== id);
    selectedGroupId = "all";
    managingMembers = false;
    $("group-dialog").close();
    await save(state, "群組已刪除；頻道資料仍保留");
  });
  $("open-home").addEventListener("click", () => api.open("https://www.youtube.com/"));
  $("open-youtube").addEventListener("click", () => api.open("https://www.youtube.com/feed/subscriptions"));
  $("update-subscriptions").addEventListener("click", async () => {
    if (!globalThis.chrome?.runtime?.sendMessage) { toast("預覽模式無法啟動掃描"); return; }
    const result = await chrome.runtime.sendMessage({ type: "START_SUBSCRIPTION_UPDATE" });
    toast(result?.ok ? "正在更新全部訂閱內容" : "無法啟動訂閱更新");
  });
  $("auto-organize").addEventListener("click", () => {
    autoSuggestions = { groups: [], uncertain: [] };
    showAutoStep("intro");
    $("auto-dialog").showModal();
  });
  $("auto-start").addEventListener("click", startAutoOrganize);
  $("auto-cancel").addEventListener("click", closeAutoDialog);
  $("auto-close").addEventListener("click", closeAutoDialog);
  $("auto-dialog").addEventListener("cancel", () => autoController?.abort());
  $("auto-apply").addEventListener("click", async () => {
    const selected = new Set([...document.querySelectorAll("[data-auto-group]:checked")].map((input) => input.dataset.autoGroup));
    const groups = autoSuggestions.groups.filter((group) => selected.has(group.groupId));
    if (!groups.length) { toast("請至少選擇一個分類建議"); return; }
    const count = groups.reduce((sum, group) => sum + group.channelIds.length, 0);
    await save(Core.applyAutoGroupSuggestions(state, groups), `已整理 ${count} 個頻道`);
    $("auto-dialog").close();
  });
  document.querySelectorAll("[data-setting]").forEach((input) => input.addEventListener("change", async () => {
    state.settings = Core.settingsAfterToggle(state.settings, input.dataset.setting, input.checked);
    await save(state, input.dataset.setting === "hideSecondary" && input.checked ? "已隱藏影片右側欄，並關閉自動播放" : "設定已儲存");
  }));
  $("export").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const link = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `tubeshelf-backup-${new Date().toISOString().slice(0, 10)}.json` });
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    toast("備份已匯出");
  });
  $("import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try { await save(JSON.parse(await file.text()), "備份已匯入"); }
    catch (_error) { toast("這不是有效的 TubeShelf 備份"); }
    event.target.value = "";
  });
  $("reset").addEventListener("click", async () => {
    if (!confirm("要清除 TubeShelf 的本機群組與已收集頻道嗎？這不會取消 YouTube 訂閱。")) return;
    selectedGroupId = "all";
    managingMembers = false;
    await save(Core.defaultState(), "本機資料已清除");
  });

  window.addEventListener("resize", scheduleWorkspaceLayout);

  (async function init() { state = Core.normalizeState(await api.load()); render(); })();
})();
