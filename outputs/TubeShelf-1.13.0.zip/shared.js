(function (root, factory) {
  const api = factory();
  root.TubeShelfCore = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const VERSION = 9;
  const DEFAULT_GROUPS = [
    { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: [] },
    { id: "relax", name: "放鬆", icon: "sparkles", color: "#ff6b8a", channelIds: [] }
  ];

  const ICONS = {
    book: "M5 4.8A2.8 2.8 0 0 1 7.8 2H11v15H7.8A2.8 2.8 0 0 0 5 19.8V4.8Zm14 0A2.8 2.8 0 0 0 16.2 2H13v15h3.2a2.8 2.8 0 0 1 2.8 2.8V4.8Z",
    sparkles: "m12 2 1.1 3.4a5.5 5.5 0 0 0 3.5 3.5L20 10l-3.4 1.1a5.5 5.5 0 0 0-3.5 3.5L12 18l-1.1-3.4a5.5 5.5 0 0 0-3.5-3.5L4 10l3.4-1.1a5.5 5.5 0 0 0 3.5-3.5L12 2Zm7 14 .6 1.7a2.8 2.8 0 0 0 1.7 1.7l1.7.6-1.7.6a2.8 2.8 0 0 0-1.7 1.7L19 24l-.6-1.7a2.8 2.8 0 0 0-1.7-1.7L15 20l1.7-.6a2.8 2.8 0 0 0 1.7-1.7L19 16Z",
    game: "M8 7h8a6 6 0 0 1 5.7 7.9l-1.1 3.4a2.4 2.4 0 0 1-4.1.8L14.8 17H9.2l-1.7 2.1a2.4 2.4 0 0 1-4.1-.8l-1.1-3.4A6 6 0 0 1 8 7Zm0 3v2H6v2h2v2h2v-2h2v-2h-2v-2H8Zm8.5 2a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Zm2.5 3a1.2 1.2 0 1 0 0-2.4A1.2 1.2 0 0 0 19 15Z",
    music: "M18 3v13.1A4 4 0 1 1 16 13V7l-7 2v9.1A4 4 0 1 1 7 15V6l11-3Z",
    code: "m9 6-6 6 6 6 1.5-1.5L6 12l4.5-4.5L9 6Zm6 0-1.5 1.5L18 12l-4.5 4.5L15 18l6-6-6-6Z",
    star: "m12 2.8 2.8 5.7 6.3.9-4.6 4.5 1.1 6.3-5.6-3-5.6 3 1.1-6.3-4.6-4.5 6.3-.9L12 2.8Z"
  };

  const AUTO_GROUPS = [
    { id: "games", name: "遊戲", icon: "game", color: "#2dbd9b", keywords: ["遊戲", "實況", "攻略", "電競", "手遊", "主機", "game", "gaming", "gameplay", "gamer", "esports", "steam", "nintendo", "playstation", "xbox", "minecraft", "godot", "unity", "osu", "gta", "pokemon"] },
    { id: "music", name: "音樂", icon: "music", color: "#ff6b8a", keywords: ["音樂", "歌曲", "歌手", "翻唱", "演奏", "鋼琴", "吉他", "樂團", "作曲", "music", "song", "singer", "cover", "concert", "piano", "guitar", "jazz", "lofi", "lyrics", "official audio", "official mv"] },
    { id: "technology", name: "科技", icon: "code", color: "#4a91ff", keywords: ["科技", "程式", "軟體", "硬體", "電腦", "開發者", "人工智慧", "手機", "評測", "tech", "technology", "programming", "coding", "developer", "software", "hardware", "computer", "windows", "linux", "javascript", "python", "android", "iphone", "chatgpt", "ai"] },
    { id: "learning", name: "學習", icon: "book", color: "#7c5cff", keywords: ["學習", "知識", "科普", "教學", "歷史", "數學", "物理", "化學", "語言", "心理", "哲學", "法律", "science", "education", "educational", "tutorial", "history", "math", "physics", "chemistry", "documentary", "explained", "lecture", "course"] },
    { id: "news", name: "新聞與時事", icon: "star", color: "#f0a44b", keywords: ["新聞", "時事", "政治", "國際", "報導", "評論", "媒體", "news", "politics", "current affairs", "reporter", "journalism", "breaking news", "world news"] },
    { id: "finance", name: "投資與財經", icon: "star", color: "#e5ad45", keywords: ["投資", "股票", "理財", "財經", "經濟", "商業", "加密貨幣", "比特幣", "finance", "investment", "investing", "stock", "economy", "business", "crypto", "bitcoin", "trading", "market"] },
    { id: "art", name: "藝術與動畫", icon: "sparkles", color: "#bc6fe8", keywords: ["藝術", "繪畫", "插畫", "動畫", "設計", "攝影", "漫畫", "剪輯", "art", "artist", "drawing", "illustration", "animation", "anime", "design", "photography", "filmmaking", "creative"] },
    { id: "entertainment", name: "娛樂與影劇", icon: "sparkles", color: "#e56fa8", keywords: ["娛樂", "搞笑", "喜劇", "電影", "戲劇", "影劇", "訪談", "脫口秀", "虛擬實況主", "娛樂新聞", "comedy", "movie", "film", "cinema", "drama", "reaction", "podcast", "interview", "talk show", "vtuber", "hololive", "streamer"] },
    { id: "food", name: "美食", icon: "sparkles", color: "#ff8a5c", keywords: ["美食", "料理", "食譜", "烹飪", "餐廳", "甜點", "吃播", "food", "cooking", "recipe", "restaurant", "kitchen", "chef", "dessert", "street food", "mukbang"] },
    { id: "sports", name: "運動", icon: "star", color: "#4bb6df", keywords: ["運動", "棒球", "籃球", "足球", "網球", "健身", "賽車", "體育", "sports", "baseball", "basketball", "football", "soccer", "tennis", "fitness", "workout", "racing", "nba", "mlb"] },
    { id: "vehicles", name: "汽機車", icon: "star", color: "#8f98a8", keywords: ["汽車", "機車", "試駕", "車評", "改裝車", "電動車", "automotive", "car review", "motorcycle", "supercar", "vehicle", "tesla"] },
    { id: "animals", name: "動物與寵物", icon: "sparkles", color: "#d3a35f", keywords: ["動物", "寵物", "貓咪", "狗狗", "萌寵", "animal", "pet", "cat", "dog", "wildlife"] },
    { id: "life", name: "生活", icon: "sparkles", color: "#51c58a", keywords: ["生活", "日常", "旅行", "旅遊", "開箱", "健康", "居家", "家庭", "vlog", "lifestyle", "travel", "unboxing", "health", "daily", "family", "home"] }
  ];

  const INTERNAL_TOPICS = [
    { id: "gameplay", label: "遊戲內容", groupId: "games", phrases: ["遊戲實況", "遊戲攻略", "新手攻略", "gameplay", "gaming", "let's play", "実況", "ゲーム実況", "攻略", "手遊", "電競", "esports", "steam", "nintendo", "playstation", "xbox", "minecraft", "pokemon", "gta"] },
    { id: "game-development", label: "遊戲開發", groupId: "games", phrases: ["遊戲開發", "遊戲製作", "game development", "game dev", "gamedev", "godot", "unity tutorial", "unreal engine", "indie game"] },
    { id: "music-performance", label: "音樂與演奏", groupId: "music", phrases: ["音樂", "歌曲", "歌手", "翻唱", "演奏", "鋼琴", "吉他", "樂團", "音楽", "歌ってみた", "演奏してみた", "music", "song", "singer", "cover song", "concert", "piano", "guitar", "jazz", "lofi", "lyrics", "official audio", "official mv"] },
    { id: "music-production", label: "音樂製作", groupId: "music", phrases: ["音樂製作", "編曲", "混音", "作曲", "beatmaking", "music production", "mixing", "mastering", "composer", "vocaloid"] },
    { id: "software", label: "程式與軟體", groupId: "technology", phrases: ["程式設計", "軟體開發", "網頁開發", "開發者", "programming", "coding", "developer", "software", "javascript", "typescript", "python", "rust language", "linux", "github", "open source"] },
    { id: "hardware", label: "電腦與硬體", groupId: "technology", phrases: ["電腦硬體", "電腦組裝", "顯示卡", "處理器", "主機板", "硬體評測", "computer hardware", "pc build", "graphics card", "gpu review", "cpu review", "laptop review"] },
    { id: "consumer-tech", label: "消費科技", groupId: "technology", phrases: ["科技評測", "手機評測", "開箱評測", "智慧型手機", "ガジェット", "tech review", "technology", "smartphone", "android", "iphone", "ipad", "wearable"] },
    { id: "artificial-intelligence", label: "人工智慧", groupId: "technology", phrases: ["人工智慧", "機器學習", "生成式 ai", "大型語言模型", "machine learning", "generative ai", "large language model", "chatgpt", "stable diffusion", "midjourney"], excludes: ["ai cover", "ai翻唱", "ai 翻唱"] },
    { id: "science", label: "科學與科普", groupId: "learning", phrases: ["科普", "科學", "物理", "化學", "生物學", "天文", "science", "scientific", "physics", "chemistry", "biology", "astronomy", "explained"] },
    { id: "humanities", label: "人文與歷史", groupId: "learning", phrases: ["歷史", "哲學", "心理學", "社會學", "法律", "考古", "history", "philosophy", "psychology", "sociology", "law", "archaeology", "documentary"] },
    { id: "education", label: "教育與課程", groupId: "learning", phrases: ["教育", "學習", "課程", "講座", "教學頻道", "語言學習", "education", "educational", "course", "lecture", "language learning", "lesson", "tutorial"] },
    { id: "journalism", label: "新聞與報導", groupId: "news", phrases: ["新聞", "時事", "國際新聞", "調查報導", "記者", "新聞網", "news", "current affairs", "reporter", "journalism", "breaking news", "world news"] },
    { id: "politics", label: "政治與公共事務", groupId: "news", phrases: ["政治", "國會", "選舉", "公共政策", "地緣政治", "politics", "election", "public policy", "geopolitics", "military affairs"] },
    { id: "investing", label: "投資與市場", groupId: "finance", phrases: ["投資", "股票", "理財", "財經", "加密貨幣", "比特幣", "investment", "investing", "stock market", "finance", "crypto", "bitcoin", "trading", "market analysis"] },
    { id: "business", label: "商業與經濟", groupId: "finance", phrases: ["商業", "經濟", "創業", "企業經營", "職場", "business", "economy", "economics", "entrepreneur", "startup", "career"] },
    { id: "visual-art", label: "繪畫與設計", groupId: "art", phrases: ["繪畫", "插畫", "繪圖過程", "漫畫", "攝影", "平面設計", "イラスト", "お絵描き", "art", "artist", "drawing", "illustration", "speedpaint", "photography", "graphic design"] },
    { id: "animation", label: "動畫製作", groupId: "art", phrases: ["動畫製作", "動畫教學", "動畫創作", "アニメーション", "animation making", "animation tutorial", "motion design", "3d animation", "blender animation"] },
    { id: "film-tv", label: "影劇與評論", groupId: "entertainment", phrases: ["電影評論", "影劇評論", "戲劇", "電影解析", "影評", "映画", "movie review", "film review", "cinema", "drama", "tv show", "television"] },
    { id: "comedy-variety", label: "喜劇與綜藝", groupId: "entertainment", phrases: ["搞笑", "喜劇", "綜藝", "脫口秀", "反應影片", "お笑い", "comedy", "funny", "variety show", "talk show", "reaction video"] },
    { id: "creator-streaming", label: "直播與創作者", groupId: "entertainment", phrases: ["虛擬實況主", "直播精華", "實況精華", "vtuber", "hololive", "nijisanji", "streamer", "podcast", "interview"] },
    { id: "cooking", label: "料理與食譜", groupId: "food", phrases: ["料理", "食譜", "烹飪", "甜點", "料理教學", "料理研究", "料理動画", "レシピ", "cooking", "recipe", "kitchen", "chef", "dessert", "baking"] },
    { id: "food-review", label: "餐廳與美食", groupId: "food", phrases: ["美食", "餐廳", "吃播", "街頭美食", "探店", "food review", "restaurant", "street food", "mukbang", "foodie"] },
    { id: "fitness", label: "健身與運動", groupId: "sports", phrases: ["健身", "重訓", "瑜珈", "跑步", "運動訓練", "fitness", "workout", "bodybuilding", "weightlifting", "yoga", "running"] },
    { id: "competitive-sports", label: "球類與賽事", groupId: "sports", phrases: ["棒球", "籃球", "足球", "網球", "體育賽事", "baseball", "basketball", "football", "soccer", "tennis", "nba", "mlb", "sports highlights"] },
    { id: "cars", label: "汽車", groupId: "vehicles", phrases: ["汽車", "試駕", "車評", "改裝車", "電動車", "新車介紹", "automotive", "car review", "supercar", "electric vehicle", "tesla"] },
    { id: "motorcycles", label: "機車", groupId: "vehicles", phrases: ["機車", "重機", "摩托車", "騎士", "motorcycle", "motorbike", "scooter", "rider"] },
    { id: "pets", label: "寵物", groupId: "animals", phrases: ["寵物", "貓咪", "狗狗", "萌寵", "毛小孩", "ペット", "猫", "犬", "pet", "cat", "dog"] },
    { id: "wildlife", label: "動物與自然", groupId: "animals", phrases: ["野生動物", "動物紀錄", "自然生態", "wildlife", "animal rescue", "nature documentary", "zoology"] },
    { id: "travel", label: "旅行與觀光", groupId: "life", phrases: ["旅行", "旅遊", "觀光", "住宿", "航空", "旅行 vlog", "旅行記", "travel", "tourism", "hotel", "flight review", "backpacking"] },
    { id: "home-diy", label: "居家與手作", groupId: "life", phrases: ["居家", "收納", "裝潢", "手作", "木工", "園藝", "home improvement", "interior design", "diy", "woodworking", "gardening"] },
    { id: "fashion-beauty", label: "時尚與美容", groupId: "life", phrases: ["時尚", "穿搭", "美妝", "保養", "髮型", "fashion", "beauty", "makeup", "skincare", "hairstyle"] },
    { id: "health-wellness", label: "健康與身心", groupId: "life", phrases: ["健康", "營養", "醫療", "睡眠", "心理健康", "health", "wellness", "nutrition", "medical", "mental health", "sleep"] },
    { id: "daily-life", label: "生活紀錄", groupId: "life", phrases: ["生活日常", "日常生活", "家庭生活", "育兒", "daily vlog", "daily life", "family vlog", "parenting", "lifestyle vlog"] }
  ];

  const VIDEO_CATEGORY_GROUPS = {
    "1": { groupId: "art", label: "Film & Animation", weight: 5 },
    "2": { groupId: "vehicles", label: "Autos & Vehicles", weight: 10 },
    "10": { groupId: "music", label: "Music", weight: 10 },
    "15": { groupId: "animals", label: "Pets & Animals", weight: 10 },
    "17": { groupId: "sports", label: "Sports", weight: 10 },
    "19": { groupId: "life", label: "Travel & Events", weight: 8 },
    "20": { groupId: "games", label: "Gaming", weight: 10 },
    "23": { groupId: "entertainment", label: "Comedy", weight: 9 },
    "24": { groupId: "entertainment", label: "Entertainment", weight: 5 },
    "25": { groupId: "news", label: "News & Politics", weight: 10 },
    "26": { groupId: "life", label: "Howto & Style", weight: 4 },
    "27": { groupId: "learning", label: "Education", weight: 9 },
    "28": { groupId: "technology", label: "Science & Technology", weight: 8 },
    "29": { groupId: "news", label: "Nonprofits & Activism", weight: 4 }
  };

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function cleanChannelName(value, fallback) {
    const firstLine = String(value || "").split(/[\r\n]+/).map((part) => part.trim()).find(Boolean) || String(fallback || "");
    const compact = firstLine.replace(/\s+/g, " ").trim();
    for (let cut = 4; cut <= compact.length / 2 + 1; cut += 1) {
      if (compact.slice(0, cut).trim() === compact.slice(cut).trim()) return compact.slice(0, cut).trim();
    }
    return compact;
  }

  function sanitizeDescription(value) {
    const description = String(value || "").trim();
    const boilerplate = [
      "與好友、家人及全世界分享你的影片",
      "与好友、家人和全世界分享你的视频",
      "share your videos with friends, family, and the world"
    ];
    return boilerplate.some((text) => description.toLowerCase() === text.toLowerCase()) ? "" : description;
  }

  function sanitizeChannelKeywords(value) {
    const generic = new Set(["影片", "視頻", "视频", "分享", "可拍照的手機", "影像電話", "免費", "上传", "上傳", "video", "videos", "sharing", "camera phone", "video phone", "free", "upload"]);
    return String(value || "").split(/[,，]+/).map((part) => part.trim()).filter((part) => part && !generic.has(part.toLowerCase())).join(", ");
  }

  function defaultState() {
    return {
      version: VERSION,
      groups: clone(DEFAULT_GROUPS),
      channels: {},
      manualLabels: {},
      settings: {
        blockHome: false,
        hideShorts: false,
        hideSecondary: false,
        disableAutoplay: false,
        hideWatched: false,
        compactMode: false,
        onboardingComplete: false
      }
    };
  }

  function normalizeState(input) {
    const base = defaultState();
    if (!input || typeof input !== "object") return base;
    const rawChannels = input.channels && typeof input.channels === "object" ? input.channels : {};
    const channels = Object.fromEntries(Object.entries(rawChannels).filter(([, channel]) => channel && typeof channel === "object").map(([id, channel]) => [id, {
      ...channel,
      id,
      name: cleanChannelName(channel.name, id).slice(0, 120),
      description: sanitizeDescription(channel.description).slice(0, 2000),
      keywords: sanitizeChannelKeywords(channel.keywords).slice(0, 1000),
      recentTitles: Array.isArray(channel.recentTitles) ? channel.recentTitles.map((title) => String(title).trim()).filter(Boolean).slice(0, 20) : [],
      recentVideoIds: Array.isArray(channel.recentVideoIds) ? channel.recentVideoIds.map(String).filter(Boolean).slice(0, 20) : [],
      topicCategories: Array.isArray(channel.topicCategories) ? channel.topicCategories.map(String).filter(Boolean).slice(0, 20) : [],
      topicIds: Array.isArray(channel.topicIds) ? channel.topicIds.map(String).filter(Boolean).slice(0, 20) : [],
      videoCategoryCounts: channel.videoCategoryCounts && typeof channel.videoCategoryCounts === "object" ? Object.fromEntries(Object.entries(channel.videoCategoryCounts).map(([key, value]) => [String(key), Math.max(0, Number(value) || 0)]).filter(([, value]) => value > 0)) : {},
      officialTags: Array.isArray(channel.officialTags) ? channel.officialTags.map(String).filter(Boolean).slice(0, 40) : [],
      officialProfiledAt: Number(channel.officialProfiledAt) || 0
    }]));
    const groups = Array.isArray(input.groups)
      ? input.groups
          .filter((group) => group && typeof group.name === "string")
          .map((group, index) => ({
            id: String(group.id || `group-${index + 1}`),
            name: group.name.trim().slice(0, 40) || `群組 ${index + 1}`,
            icon: ICONS[group.icon] ? group.icon : "star",
            color: /^#[0-9a-f]{6}$/i.test(group.color || "") ? group.color : "#7c5cff",
            channelIds: Array.isArray(group.channelIds)
              ? [...new Set(group.channelIds.map(String).filter((id) => channels[id]))]
              : []
          }))
      : base.groups;
    const validGroupIds = new Set(groups.map((group) => group.id));
    const manualLabels = Object.fromEntries(Object.entries(input.manualLabels && typeof input.manualLabels === "object" ? input.manualLabels : {})
      .filter(([channelId, groupIds]) => channels[channelId] && Array.isArray(groupIds))
      .map(([channelId, groupIds]) => [channelId, [...new Set(groupIds.map(String).filter((groupId) => validGroupIds.has(groupId)))]])
      .filter(([, groupIds]) => groupIds.length));
    return {
      version: VERSION,
      groups,
      channels,
      manualLabels,
      settings: { ...base.settings, ...(input.settings || {}) }
    };
  }

  function channelKey(url) {
    if (!url || typeof url !== "string") return "";
    try {
      const parsed = new URL(url, "https://www.youtube.com");
      const path = parsed.pathname.replace(/\/$/, "");
      if (!/^\/(channel\/|@|c\/|user\/)/i.test(path)) return "";
      const parts = path.split("/").filter(Boolean);
      if (!parts.length) return "";
      const stableParts = parts[0].startsWith("@") ? [parts[0]] : parts.slice(0, 2);
      return `/${stableParts.join("/")}`.toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  function youtubePageKind(value) {
    try {
      const pathname = String(value || "").startsWith("http") ? new URL(value).pathname : String(value || "").split(/[?#]/)[0];
      if (pathname === "/" || pathname === "") return "home";
      if (pathname === "/feed/subscriptions") return "subscriptions";
      return "other";
    } catch (_error) {
      return "other";
    }
  }

  function subscriptionGroupUrl(groupId) {
    const id = String(groupId || "all");
    return `https://www.youtube.com/feed/subscriptions#tubeshelf-group=${encodeURIComponent(id)}`;
  }

  function settingsAfterToggle(settings, setting, enabled) {
    const next = { ...defaultState().settings, ...(settings || {}), [setting]: Boolean(enabled) };
    if (setting === "hideSecondary" && enabled) next.disableAutoplay = true;
    return next;
  }

  function blockedPageRedirect(settings, value) {
    let pathname = "";
    try {
      pathname = String(value || "").startsWith("http") ? new URL(value).pathname : String(value || "").split(/[?#]/)[0];
    } catch (_error) {}
    if (settings?.blockHome && youtubePageKind(value) === "home") return subscriptionGroupUrl("all");
    if (settings?.hideShorts && pathname.startsWith("/shorts")) return subscriptionGroupUrl("all");
    return "";
  }

  function createId(name, usedIds) {
    const base = String(name || "group")
      .normalize("NFKD")
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fff]+/g, "-")
      .replace(/^-|-$/g, "") || "group";
    let id = base;
    let suffix = 2;
    while (usedIds.includes(id)) id = `${base}-${suffix++}`;
    return id;
  }

  function upsertChannels(state, incoming) {
    const next = normalizeState(state);
    for (const channel of incoming || []) {
      const id = channelKey(channel.url || channel.id);
      if (!id) continue;
      next.channels[id] = {
        id,
        name: cleanChannelName(channel.name || next.channels[id]?.name, id).slice(0, 120),
        url: `https://www.youtube.com${id}`,
        avatar: typeof channel.avatar === "string" ? channel.avatar : next.channels[id]?.avatar || "",
        seenAt: Number(channel.seenAt) || Date.now(),
        description: sanitizeDescription(channel.description || next.channels[id]?.description).slice(0, 2000),
        keywords: sanitizeChannelKeywords(channel.keywords || next.channels[id]?.keywords).slice(0, 1000),
        channelId: String(channel.channelId || next.channels[id]?.channelId || "").trim(),
        recentTitles: Array.isArray(channel.recentTitles) ? channel.recentTitles.map(String).slice(0, 20) : next.channels[id]?.recentTitles || [],
        recentVideoIds: Array.isArray(channel.recentVideoIds) ? channel.recentVideoIds.map(String).slice(0, 20) : next.channels[id]?.recentVideoIds || [],
        topicCategories: Array.isArray(channel.topicCategories) ? channel.topicCategories.map(String).slice(0, 20) : next.channels[id]?.topicCategories || [],
        topicIds: Array.isArray(channel.topicIds) ? channel.topicIds.map(String).slice(0, 20) : next.channels[id]?.topicIds || [],
        videoCategoryCounts: channel.videoCategoryCounts || next.channels[id]?.videoCategoryCounts || {},
        officialTags: Array.isArray(channel.officialTags) ? channel.officialTags.map(String).slice(0, 40) : next.channels[id]?.officialTags || [],
        officialProfiledAt: Number(channel.officialProfiledAt) || Number(next.channels[id]?.officialProfiledAt) || 0,
        profiledAt: Number(channel.profiledAt) || Number(next.channels[id]?.profiledAt) || 0,
        profileVersion: Number(channel.profileVersion) || Number(next.channels[id]?.profileVersion) || 0
      };
    }
    return next;
  }

  function replaceChannels(state, incoming) {
    const current = normalizeState(state);
    const channels = {};
    for (const channel of incoming || []) {
      const id = channelKey(channel.url || channel.id);
      if (!id) continue;
      channels[id] = {
        id,
        name: cleanChannelName(channel.name || current.channels[id]?.name, id).slice(0, 120),
        url: `https://www.youtube.com${id}`,
        avatar: typeof channel.avatar === "string" ? channel.avatar : current.channels[id]?.avatar || "",
        seenAt: Number(channel.seenAt) || Date.now(),
        description: sanitizeDescription(channel.description || current.channels[id]?.description).slice(0, 2000),
        keywords: sanitizeChannelKeywords(channel.keywords || current.channels[id]?.keywords).slice(0, 1000),
        channelId: String(channel.channelId || current.channels[id]?.channelId || "").trim(),
        recentTitles: Array.isArray(channel.recentTitles) ? channel.recentTitles.map(String).slice(0, 20) : current.channels[id]?.recentTitles || [],
        recentVideoIds: Array.isArray(channel.recentVideoIds) ? channel.recentVideoIds.map(String).slice(0, 20) : current.channels[id]?.recentVideoIds || [],
        topicCategories: Array.isArray(channel.topicCategories) ? channel.topicCategories.map(String).slice(0, 20) : current.channels[id]?.topicCategories || [],
        topicIds: Array.isArray(channel.topicIds) ? channel.topicIds.map(String).slice(0, 20) : current.channels[id]?.topicIds || [],
        videoCategoryCounts: channel.videoCategoryCounts || current.channels[id]?.videoCategoryCounts || {},
        officialTags: Array.isArray(channel.officialTags) ? channel.officialTags.map(String).slice(0, 40) : current.channels[id]?.officialTags || [],
        officialProfiledAt: Number(channel.officialProfiledAt) || Number(current.channels[id]?.officialProfiledAt) || 0,
        profiledAt: Number(channel.profiledAt) || Number(current.channels[id]?.profiledAt) || 0,
        profileVersion: Number(channel.profileVersion) || Number(current.channels[id]?.profileVersion) || 0
      };
    }
    return normalizeState({
      ...current,
      channels,
      groups: current.groups.map((group) => ({ ...group, channelIds: group.channelIds.filter((id) => channels[id]) }))
    });
  }

  function groupForChannel(state, id) {
    return normalizeState(state).groups.filter((group) => group.channelIds.includes(id));
  }

  function unfiledChannelIds(state) {
    const current = normalizeState(state);
    const filed = new Set(current.groups.flatMap((group) => group.channelIds));
    return Object.keys(current.channels).filter((id) => !filed.has(id));
  }

  function keywordMatches(text, keyword) {
    const source = String(text || "").toLowerCase();
    const needle = String(keyword || "").toLowerCase();
    if (!needle) return false;
    if (/^[a-z0-9]+$/.test(needle) && needle.length <= 3) {
      const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(source);
    }
    return source.includes(needle);
  }

  function collectRecentVideos(initialData) {
    const videos = [];
    const seen = new Set();
    function textFromRuns(value) {
      if (!value || typeof value !== "object") return "";
      if (typeof value.simpleText === "string") return value.simpleText.trim();
      if (Array.isArray(value.runs)) return value.runs.map((run) => run?.text || "").join("").trim();
      return "";
    }
    function add(id, title) {
      const clean = String(title || "").trim();
      const videoId = String(id || "").trim();
      const key = videoId || clean;
      if (clean && !seen.has(key) && videos.length < 20) { seen.add(key); videos.push({ id: videoId, title: clean }); }
    }
    function visit(node) {
      if (!node || videos.length >= 20) return;
      if (Array.isArray(node)) { node.forEach(visit); return; }
      if (typeof node !== "object") return;
      for (const key of ["videoRenderer", "gridVideoRenderer", "compactVideoRenderer"]) add(node[key]?.videoId, textFromRuns(node[key]?.title));
      const lockup = node.lockupViewModel;
      if (lockup?.contentType === "LOCKUP_CONTENT_TYPE_VIDEO") add(lockup.contentId || lockup.videoId, lockup.metadata?.lockupMetadataViewModel?.title?.content);
      Object.values(node).forEach(visit);
    }
    visit(initialData);
    return videos;
  }

  function collectRecentVideoTitles(initialData) {
    return collectRecentVideos(initialData).map((video) => video.title);
  }

  const LEARNING_STOP_WORDS = new Set(["the", "and", "for", "with", "from", "this", "that", "your", "you", "channel", "video", "videos", "official", "youtube", "頻道", "影片", "官方", "分享", "訂閱", "觀看", "最新", "我們", "我的", "一個", "以及", "可以", "介紹", "教學", "日常", "です", "ます", "動画", "チャンネル"]);
  const WORD_SEGMENTER = typeof Intl?.Segmenter === "function" ? new Intl.Segmenter("zh-Hant", { granularity: "word" }) : null;

  function normalizedTopicName(value) {
    const raw = String(value || "");
    const tail = raw.includes("/") ? raw.slice(raw.lastIndexOf("/") + 1) : raw;
    try { return decodeURIComponent(tail).replace(/_/g, " ").toLowerCase(); }
    catch (_error) { return tail.replace(/_/g, " ").toLowerCase(); }
  }

  function officialTopicGroup(value) {
    const topicIdGroups = {
      "/m/04rlf": "music", "/m/0bzvm2": "games", "/m/06ntj": "sports", "/m/02jjt": "entertainment", "/m/09kqc": "entertainment", "/m/02vxn": "entertainment", "/m/05qjc": "entertainment", "/m/0f2f9": "entertainment", "/m/019_rr": "life", "/m/032tl": "life", "/m/027x7n": "sports", "/m/02wbm": "food", "/m/03glg": "life", "/m/068hy": "animals", "/m/041xxh": "life", "/m/07c1v": "technology", "/m/07bxq": "life", "/m/07yv9": "vehicles", "/m/09s1f": "finance", "/m/0kt51": "life", "/m/01h6rj": "news", "/m/05qt0": "news", "/m/01k8wb": "learning"
    };
    if (topicIdGroups[String(value || "")]) return topicIdGroups[String(value || "")];
    const topic = normalizedTopicName(value);
    const rules = [
      [/gaming|video game|action game|role-playing|strategy game|simulation game|puzzle game|racing game/, "games"],
      [/music|jazz|hip hop|rhythm and blues|reggae|rock|soul|classical/, "music"],
      [/sport|football|baseball|basketball|boxing|cricket|golf|hockey|tennis|volleyball|wrestling|motorsport|fitness/, "sports"],
      [/technology/, "technology"],
      [/knowledge/, "learning"],
      [/politic|military/, "news"],
      [/business/, "finance"],
      [/food/, "food"],
      [/pet|animal/, "animals"],
      [/vehicle/, "vehicles"],
      [/humor|movie|performing art|tv show|entertainment/, "entertainment"],
      [/fashion|beauty|tourism|hobby|health|lifestyle/, "life"]
    ];
    return rules.find(([pattern]) => pattern.test(topic))?.[1] || "";
  }

  function learningTokens(channel) {
    const parts = [channel?.name, channel?.description, channel?.keywords, ...(Array.isArray(channel?.recentTitles) ? channel.recentTitles : [])].filter(Boolean);
    const tokens = new Set();
    for (const source of parts) {
      const text = String(source).normalize("NFKC").toLowerCase();
      const words = text.match(/[a-z][a-z0-9+#.-]{2,}/g) || [];
      words.filter((word) => !LEARNING_STOP_WORDS.has(word)).forEach((word) => tokens.add(word));
      for (let index = 0; index < words.length - 1; index += 1) {
        const phrase = `${words[index]} ${words[index + 1]}`;
        if (!LEARNING_STOP_WORDS.has(words[index]) && !LEARNING_STOP_WORDS.has(words[index + 1])) tokens.add(phrase);
      }
      try {
        if (!WORD_SEGMENTER) continue;
        for (const segment of WORD_SEGMENTER.segment(text)) {
          const word = segment.segment.trim();
          if (segment.isWordLike && /[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}]/u.test(word) && word.length >= 2 && word.length <= 10 && !LEARNING_STOP_WORDS.has(word)) tokens.add(word);
        }
      } catch (_error) {}
    }
    return tokens;
  }

  function buildLearnedProfiles(state) {
    const current = normalizeState(state);
    const groups = new Map(current.groups.map((group) => [group.id, group]));
    const groupDocuments = new Map();
    const termCounts = new Map();
    for (const [channelId, groupIds] of Object.entries(current.manualLabels)) {
      const channel = current.channels[channelId];
      if (!channel) continue;
      const tokens = learningTokens(channel);
      for (const groupId of groupIds) {
        if (!groups.has(groupId)) continue;
        groupDocuments.set(groupId, (groupDocuments.get(groupId) || 0) + 1);
        for (const token of tokens) {
          if (!termCounts.has(token)) termCounts.set(token, new Map());
          const counts = termCounts.get(token);
          counts.set(groupId, (counts.get(groupId) || 0) + 1);
        }
      }
    }
    return [...groups.values()].flatMap((group) => {
      const documentCount = groupDocuments.get(group.id) || 0;
      if (documentCount < 2) return [];
      const terms = [...termCounts.entries()].flatMap(([term, counts]) => {
        const count = counts.get(group.id) || 0;
        const total = [...counts.values()].reduce((sum, value) => sum + value, 0);
        const concentration = total ? count / total : 0;
        if (count < 2 || concentration < 0.67) return [];
        return [{ term, weight: Math.min(7, 1.5 + Math.log2(count + 1) * 1.5 + concentration * 2) }];
      }).sort((a, b) => b.weight - a.weight).slice(0, 80);
      return terms.length ? [{ groupId: group.id, name: group.name, icon: group.icon, color: group.color, terms, documentCount }] : [];
    });
  }

  function groupMetadata(groupId, state) {
    const known = AUTO_GROUPS.find((group) => group.id === groupId);
    if (known) return known;
    return (Array.isArray(state?.groups) ? state.groups : []).find((group) => group.id === groupId) || { id: groupId, name: groupId, icon: "star", color: "#7c5cff" };
  }

  function classifyChannel(channel, state, learnedProfiles) {
    const name = String(channel?.name || "");
    const description = String(channel?.description || "");
    const keywords = sanitizeChannelKeywords(`${channel?.keywords || ""}, ${(channel?.officialTags || []).join(", ")}`);
    const titles = Array.isArray(channel?.recentTitles) ? channel.recentTitles : [];
    const scores = new Map();
    const topicScores = [];
    function add(groupId, score, reason, source) {
      if (!groupId || score <= 0) return;
      if (!scores.has(groupId)) scores.set(groupId, { score: 0, reasons: [], sources: new Set() });
      const target = scores.get(groupId);
      target.score += score;
      if (reason && target.reasons.length < 5 && !target.reasons.includes(reason)) target.reasons.push(reason);
      if (source) target.sources.add(source);
    }
    for (const topic of INTERNAL_TOPICS) {
      let score = 0;
      const matches = [];
      if ((topic.excludes || []).some((phrase) => keywordMatches(`${name} ${description} ${keywords} ${titles.join(" ")}`, phrase))) continue;
      for (const phrase of topic.phrases) {
        let matched = false;
        if (keywordMatches(name, phrase)) { score += 7; matched = true; }
        if (keywordMatches(keywords, phrase)) { score += 5; matched = true; }
        if (keywordMatches(description, phrase)) { score += 4; matched = true; }
        const titleHits = Math.min(4, titles.filter((title) => keywordMatches(title, phrase)).length);
        if (titleHits) { score += titleHits === 1 ? 1 : 1 + titleHits * 1.75; matched = true; }
        if (matched && matches.length < 3) matches.push(phrase);
      }
      if (score > 0) {
        topicScores.push({ ...topic, score });
        add(topic.groupId, score, `${topic.label}：${matches.join("、")}`, "dictionary");
      }
    }
    for (const topic of [...(channel?.topicCategories || []), ...(channel?.topicIds || [])]) {
      const groupId = officialTopicGroup(topic);
      if (groupId) add(groupId, 10, `YouTube 主題：${normalizedTopicName(topic)}`, "official");
    }
    const categoryCounts = channel?.videoCategoryCounts && typeof channel.videoCategoryCounts === "object" ? channel.videoCategoryCounts : {};
    const categoryTotal = Object.values(categoryCounts).reduce((sum, value) => sum + Math.max(0, Number(value) || 0), 0);
    for (const [categoryId, countValue] of Object.entries(categoryCounts)) {
      const category = VIDEO_CATEGORY_GROUPS[categoryId];
      const count = Math.max(0, Number(countValue) || 0);
      if (!category || !count || !categoryTotal) continue;
      const ratio = count / categoryTotal;
      add(category.groupId, category.weight * Math.min(1, ratio * 1.5), `近期影片：${category.label} ${Math.round(ratio * 100)}%`, "official");
    }
    const profiles = learnedProfiles || (state ? buildLearnedProfiles(state) : []);
    const tokens = learningTokens(channel);
    for (const profile of profiles) {
      const matched = profile.terms.filter((term) => tokens.has(term.term)).slice(0, 4);
      const score = Math.min(14, matched.reduce((sum, term) => sum + term.weight, 0));
      if (score > 0) add(profile.groupId, score, `個人詞彙：${matched.map((term) => term.term).join("、")}`, "personal");
    }
    const ranked = [...scores.entries()].map(([groupId, result]) => {
      const meta = groupMetadata(groupId, state);
      const tags = topicScores.filter((topic) => topic.groupId === groupId).sort((a, b) => b.score - a.score).slice(0, 3).map((topic) => topic.label);
      return { groupId, name: meta.name, icon: meta.icon, color: meta.color, score: result.score, reasons: result.reasons, sources: [...result.sources], tags };
    }).sort((a, b) => b.score - a.score);
    const best = ranked[0];
    const runnerUp = ranked[1];
    const margin = best ? best.score - (runnerUp?.score || 0) : 0;
    if (!best || best.score < 4 || (margin < 2 && best.score < 12)) return null;
    const confidence = best.score >= 15 && margin >= 6 ? "high" : best.score >= 6 && margin >= 3 ? "medium" : "low";
    return { ...best, confidence, margin: Math.round(margin * 10) / 10, score: Math.round(best.score * 10) / 10 };
  }

  function buildAutoGroupSuggestions(state) {
    const current = normalizeState(state);
    const filed = new Set(current.groups.flatMap((group) => group.channelIds));
    const learnedProfiles = buildLearnedProfiles(current);
    const suggestions = new Map();
    const uncertain = [];
    const stats = { high: 0, medium: 0, low: 0, official: 0, personal: 0, dictionary: 0 };
    for (const channel of Object.values(current.channels)) {
      if (filed.has(channel.id)) continue;
      const result = classifyChannel(channel, current, learnedProfiles);
      if (!result) { uncertain.push(channel.id); continue; }
      stats[result.confidence] += 1;
      result.sources.forEach((source) => { if (source in stats) stats[source] += 1; });
      if (result.confidence === "low") { uncertain.push(channel.id); continue; }
      if (!suggestions.has(result.groupId)) suggestions.set(result.groupId, { ...result, channelIds: [], channels: [] });
      const target = suggestions.get(result.groupId);
      target.channelIds.push(channel.id);
      target.channels.push({ id: channel.id, name: channel.name, reasons: result.reasons, confidence: result.confidence, score: result.score, margin: result.margin, tags: result.tags, sources: result.sources });
    }
    return { groups: [...suggestions.values()], uncertain, stats, learnedProfileCount: learnedProfiles.length };
  }

  function recordManualMembership(state, channelId, groupId, enabled) {
    const next = normalizeState(state);
    const group = next.groups.find((item) => item.id === groupId);
    if (!group || !next.channels[channelId]) return next;
    group.channelIds = enabled ? [...new Set([...group.channelIds, channelId])] : group.channelIds.filter((id) => id !== channelId);
    const labels = new Set(next.manualLabels[channelId] || []);
    if (enabled) labels.add(groupId);
    else labels.delete(groupId);
    if (labels.size) next.manualLabels[channelId] = [...labels];
    else delete next.manualLabels[channelId];
    return normalizeState(next);
  }

  function applyAutoGroupSuggestions(state, suggestionGroups) {
    const next = normalizeState(state);
    for (const suggestion of suggestionGroups || []) {
      const validIds = [...new Set((suggestion.channelIds || []).filter((id) => next.channels[id]))];
      if (!validIds.length) continue;
      let group = next.groups.find((item) => item.name.trim().toLowerCase() === String(suggestion.name || "").trim().toLowerCase());
      if (!group) {
        group = {
          id: createId(suggestion.name || suggestion.groupId, next.groups.map((item) => item.id)),
          name: String(suggestion.name || "自動分類").trim().slice(0, 40),
          icon: ICONS[suggestion.icon] ? suggestion.icon : "star",
          color: /^#[0-9a-f]{6}$/i.test(suggestion.color || "") ? suggestion.color : "#7c5cff",
          channelIds: []
        };
        next.groups.push(group);
      }
      group.channelIds = [...new Set([...group.channelIds, ...validIds])];
    }
    return normalizeState(next);
  }

  function iconSvg(name, color, size) {
    const path = ICONS[name] || ICONS.star;
    const px = Number(size) || 20;
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="${px}" height="${px}" fill="${color || "currentColor"}"><path d="${path}"/></svg>`;
  }

  return {
    VERSION,
    ICONS,
    AUTO_GROUPS,
    INTERNAL_TOPICS,
    VIDEO_CATEGORY_GROUPS,
    DEFAULT_GROUPS,
    cleanChannelName,
    sanitizeDescription,
    sanitizeChannelKeywords,
    defaultState,
    normalizeState,
    channelKey,
    youtubePageKind,
    subscriptionGroupUrl,
    settingsAfterToggle,
    blockedPageRedirect,
    createId,
    upsertChannels,
    replaceChannels,
    groupForChannel,
    unfiledChannelIds,
    collectRecentVideos,
    collectRecentVideoTitles,
    buildLearnedProfiles,
    classifyChannel,
    buildAutoGroupSuggestions,
    recordManualMembership,
    applyAutoGroupSuggestions,
    iconSvg
  };
});
