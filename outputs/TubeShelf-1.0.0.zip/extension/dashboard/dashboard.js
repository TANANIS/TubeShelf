(function () {
  "use strict";
  const Core = globalThis.TubeShelfCore;
  const STORAGE_KEY = "tubeShelfState";
  const COLORS = ["#7c5cff", "#ff6b8a", "#2dbd9b", "#f0a44b", "#4a91ff", "#bc6fe8"];
  let state = Core.defaultState();
  let selectedGroupId = "all";
  let query = "";

  const api = globalThis.chrome?.storage?.local
    ? {
        load: async () => (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY],
        save: (value) => chrome.storage.local.set({ [STORAGE_KEY]: value }),
        open: (url) => chrome.tabs.create({ url })
      }
    : {
        load: async () => ({
          ...Core.defaultState(),
          channels: {
            "/@kurzgesagt": { id: "/@kurzgesagt", name: "Kurzgesagt – In a Nutshell", url: "https://www.youtube.com/@kurzgesagt" },
            "/@veritasium": { id: "/@veritasium", name: "Veritasium", url: "https://www.youtube.com/@veritasium" },
            "/@lofigirl": { id: "/@lofigirl", name: "Lofi Girl", url: "https://www.youtube.com/@lofigirl" },
            "/@gamemakers": { id: "/@gamemakers", name: "Game Maker's Toolkit", url: "https://www.youtube.com/@gamemakers" },
            "/@twreporter": { id: "/@twreporter", name: "報導者 The Reporter", url: "https://www.youtube.com/@twreporter" }
          },
          groups: [
            { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: ["/@kurzgesagt", "/@veritasium", "/@twreporter"] },
            { id: "relax", name: "放鬆", icon: "music", color: "#ff6b8a", channelIds: ["/@lofigirl"] },
            { id: "games", name: "遊戲設計", icon: "game", color: "#2dbd9b", channelIds: ["/@gamemakers"] }
          ]
        }),
        save: async () => {}, open: (url) => window.open(url, "_blank")
      };

  const $ = (id) => document.getElementById(id);
  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));

  async function save(next, message) {
    state = Core.normalizeState(next);
    await api.save(state);
    render();
    if (message) toast(message);
  }

  function render() {
    const channels = Object.values(state.channels);
    const filed = new Set(state.groups.flatMap((group) => group.channelIds)).size;
    const progress = channels.length ? Math.round((filed / channels.length) * 100) : 0;
    $("stat-channels").textContent = channels.length;
    $("stat-groups").textContent = state.groups.length;
    $("stat-progress").textContent = `${progress}%`;
    $("stat-unfiled").textContent = channels.length ? `${channels.length - filed} 個頻道尚未分類` : "尚無待分類頻道";
    renderGroups();
    renderChannels();
    document.querySelectorAll("[data-setting]").forEach((input) => { input.checked = Boolean(state.settings[input.dataset.setting]); });
  }

  function renderGroups() {
    const items = [{ id: "all", name: "全部頻道", icon: "star", color: "#8c8497", channelIds: Object.keys(state.channels) }, ...state.groups];
    $("group-list").innerHTML = items.map((group) => `<button class="group-item ${selectedGroupId === group.id ? "active" : ""}" data-group="${escapeHtml(group.id)}" type="button">
      <span class="group-icon" style="color:${group.color};background:${group.color}1b">${Core.iconSvg(group.icon, "currentColor", 17)}</span>
      <span class="group-copy"><strong>${escapeHtml(group.name)}</strong><small>${group.id === "all" ? "所有已收集頻道" : "自訂群組"}</small></span>
      <span class="group-number">${group.channelIds.length}</span>
    </button>`).join("");
  }

  function renderChannels() {
    const selected = state.groups.find((group) => group.id === selectedGroupId);
    $("selected-title").textContent = selected?.name || "全部頻道";
    $("selected-subtitle").textContent = selected ? "切換右側開關以加入或移出這個群組" : "查看所有已從 YouTube 收集的頻道";
    $("membership-heading").textContent = selected ? "加入群組" : "操作";
    const channels = Object.values(state.channels)
      .filter((channel) => !query || channel.name.toLowerCase().includes(query) || channel.id.includes(query))
      .sort((a, b) => a.name.localeCompare(b.name, "zh-Hant"));
    if (!channels.length) {
      $("channel-list").innerHTML = `<div class="empty-state"><div class="empty-icon">${Core.iconSvg(query ? "star" : "book", "currentColor", 25)}</div><strong>${query ? "找不到符合的頻道" : "書架還是空的"}</strong><p>${query ? "換個關鍵字再試一次。" : "請開啟 YouTube 的「所有訂閱內容」頁面，再按擴充套件裡的「掃描此頁」。"}</p></div>`;
      return;
    }
    $("channel-list").innerHTML = channels.map((channel) => {
      const memberships = Core.groupForChannel(state, channel.id);
      const avatar = channel.avatar ? `<img src="${escapeHtml(channel.avatar)}" alt="" referrerpolicy="no-referrer" />` : escapeHtml(channel.name.slice(0, 1).toUpperCase());
      const chips = memberships.length ? memberships.slice(0, 3).map((group) => `<span class="chip" style="color:${group.color};background:${group.color}17">${escapeHtml(group.name)}</span>`).join("") : '<span class="unfiled">尚未分類</span>';
      const control = selected
        ? `<button class="member-toggle" data-channel="${escapeHtml(channel.id)}" role="switch" aria-label="${escapeHtml(channel.name)} 加入 ${escapeHtml(selected.name)}" aria-checked="${selected.channelIds.includes(channel.id)}"></button>`
        : `<a class="edit-group" href="${escapeHtml(channel.url)}" target="_blank" rel="noreferrer">開啟 ↗</a>`;
      return `<div class="channel-row"><div class="channel-main"><span class="avatar">${avatar}</span><span><span class="channel-name">${escapeHtml(channel.name)}</span><span class="channel-url">${escapeHtml(channel.id)}</span></span></div><div class="chips">${chips}</div>${control}</div>`;
    }).join("");
  }

  function openDialog(group) {
    $("dialog-title").textContent = group ? "編輯群組" : "新增群組";
    $("group-id").value = group?.id || "";
    $("group-name").value = group?.name || "";
    $("icon-options").innerHTML = Object.keys(Core.ICONS).map((icon, index) => `<label class="option-radio"><input type="radio" name="icon" value="${icon}" ${(group?.icon || "book") === icon || (!group && index === 0) ? "checked" : ""}><span>${Core.iconSvg(icon, "currentColor", 17)}</span></label>`).join("");
    $("color-options").innerHTML = COLORS.map((color, index) => `<label class="option-radio"><input type="radio" name="color" value="${color}" ${(group?.color || COLORS[0]) === color || (!group && index === 0) ? "checked" : ""}><span style="background:${color}"></span></label>`).join("");
    $("group-dialog").showModal();
    setTimeout(() => $("group-name").focus(), 30);
  }

  function toast(message) {
    const node = $("toast");
    node.textContent = message;
    node.classList.add("show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => node.classList.remove("show"), 2200);
  }

  document.querySelectorAll(".nav-item").forEach((button) => button.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach((item) => item.classList.toggle("active", item === button));
    const settings = button.dataset.view === "settings";
    $("library-view").hidden = settings;
    $("settings-view").hidden = !settings;
    document.querySelector(".page-header h1").textContent = settings ? "偏好設定" : "訂閱書架";
    document.querySelector(".page-header > div > p:last-child").textContent = settings ? "控制 YouTube 頁面上的顯示方式與本機資料。" : "把頻道放進不同群組，回到 YouTube 就能一鍵篩選。";
  }));
  $("group-list").addEventListener("click", (event) => { const id = event.target.closest("[data-group]")?.dataset.group; if (id) { selectedGroupId = id; render(); } });
  $("channel-list").addEventListener("click", async (event) => {
    const id = event.target.closest("[data-channel]")?.dataset.channel;
    const group = state.groups.find((item) => item.id === selectedGroupId);
    if (!id || !group) return;
    group.channelIds = group.channelIds.includes(id) ? group.channelIds.filter((item) => item !== id) : [...group.channelIds, id];
    await save(state, group.channelIds.includes(id) ? `已加入「${group.name}」` : `已移出「${group.name}」`);
  });
  $("search").addEventListener("input", (event) => { query = event.target.value.trim().toLowerCase(); renderChannels(); });
  [$("new-group"), $("mini-add")].forEach((button) => button.addEventListener("click", () => openDialog()));
  document.querySelectorAll("[data-dialog-close]").forEach((button) => button.addEventListener("click", () => $("group-dialog").close()));
  $("group-list").addEventListener("dblclick", (event) => { const id = event.target.closest("[data-group]")?.dataset.group; const group = state.groups.find((item) => item.id === id); if (group) openDialog(group); });
  $("group-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = $("group-name").value.trim();
    if (!name) return;
    const id = $("group-id").value;
    const icon = new FormData(event.currentTarget).get("icon") || "star";
    const color = new FormData(event.currentTarget).get("color") || COLORS[0];
    if (id) {
      const group = state.groups.find((item) => item.id === id);
      if (group) Object.assign(group, { name, icon, color });
    } else {
      state.groups.push({ id: Core.createId(name, state.groups.map((item) => item.id)), name, icon, color, channelIds: [] });
    }
    $("group-dialog").close();
    await save(state, id ? "群組已更新" : "群組已建立");
  });
  $("open-youtube").addEventListener("click", () => api.open("https://www.youtube.com/feed/channels"));
  document.querySelectorAll("[data-setting]").forEach((input) => input.addEventListener("change", async () => { state.settings[input.dataset.setting] = input.checked; await save(state, "設定已儲存"); }));
  $("export").addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const link = Object.assign(document.createElement("a"), { href: URL.createObjectURL(blob), download: `tubeshelf-backup-${new Date().toISOString().slice(0, 10)}.json` });
    link.click();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    toast("備份已匯出");
  });
  $("import").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try { await save(JSON.parse(await file.text()), "備份已匯入"); }
    catch (_error) { toast("這不是有效的 TubeShelf 備份"); }
    event.target.value = "";
  });
  $("reset").addEventListener("click", async () => {
    if (!confirm("要清除 TubeShelf 的本機群組與已收集頻道嗎？這不會取消 YouTube 訂閱。")) return;
    selectedGroupId = "all";
    await save(Core.defaultState(), "本機資料已清除");
  });

  (async function init() { state = Core.normalizeState(await api.load()); render(); })();
})();
