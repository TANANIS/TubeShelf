(function () {
  "use strict";
  const Core = globalThis.TubeShelfCore;
  const STORAGE_KEY = "tubeShelfState";
  let state = Core.defaultState();
  let activeTab = null;

  const extensionApi = globalThis.chrome?.storage?.local
    ? {
        getState: async () => (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY],
        activeTab: async () => (await chrome.tabs.query({ active: true, currentWindow: true }))[0],
        send: (tabId, message) => chrome.tabs.sendMessage(tabId, message),
        openOptions: () => chrome.runtime.openOptionsPage(),
        onChange: (callback) => chrome.storage.onChanged.addListener(callback)
      }
    : {
        getState: async () => ({
          ...Core.defaultState(),
          channels: {
            "/@kurzgesagt": { id: "/@kurzgesagt", name: "Kurzgesagt", url: "https://www.youtube.com/@kurzgesagt" },
            "/@veritasium": { id: "/@veritasium", name: "Veritasium", url: "https://www.youtube.com/@veritasium" },
            "/@lofigirl": { id: "/@lofigirl", name: "Lofi Girl", url: "https://www.youtube.com/@lofigirl" }
          },
          groups: [
            { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: ["/@kurzgesagt", "/@veritasium"] },
            { id: "relax", name: "放鬆", icon: "music", color: "#ff6b8a", channelIds: ["/@lofigirl"] }
          ]
        }),
        activeTab: async () => ({ id: 1, url: "https://www.youtube.com/feed/subscriptions" }),
        send: async () => ({ ok: true, count: 3 }),
        openOptions: () => {},
        onChange: () => {}
      };

  const escapeHtml = (value) => String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));

  function render() {
    document.getElementById("channel-count").textContent = Object.keys(state.channels).length;
    const host = document.getElementById("groups");
    host.innerHTML = state.groups.length
      ? state.groups.map((group) => `<button class="group" data-group="${escapeHtml(group.id)}" type="button">
          <span class="group-icon" style="color:${group.color};background:${group.color}1c">${Core.iconSvg(group.icon, "currentColor", 17)}</span>
          <span><span class="group-name">${escapeHtml(group.name)}</span><span class="group-meta">YouTube 群組</span></span>
          <span class="group-count">${group.channelIds.length}</span>
        </button>`).join("")
      : '<div class="empty">還沒有群組，先建立第一個書架吧。</div>';
  }

  function renderTab() {
    const isYouTube = /^https:\/\/(www\.)?youtube\.com\//.test(activeTab?.url || "");
    const card = document.getElementById("page-card");
    card.classList.toggle("ready", isYouTube);
    document.getElementById("page-title").textContent = isYouTube ? "已連上目前的 YouTube 分頁" : "目前不是 YouTube 分頁";
    document.getElementById("page-hint").textContent = isYouTube ? "可以掃描頻道或開啟側欄" : "開啟 YouTube 後即可使用頁面整合";
    document.getElementById("sync").disabled = !isYouTube;
    document.getElementById("open-panel").disabled = !isYouTube;
  }

  async function send(message) {
    if (!activeTab?.id) return null;
    try { return await extensionApi.send(activeTab.id, message); }
    catch (_error) { return null; }
  }

  document.getElementById("manage-top").addEventListener("click", extensionApi.openOptions);
  document.getElementById("add-group").addEventListener("click", extensionApi.openOptions);
  document.getElementById("open-panel").addEventListener("click", async () => {
    await send({ type: "OPEN_TUBESHELF" });
    window.close();
  });
  document.getElementById("sync").addEventListener("click", async (event) => {
    const button = event.currentTarget;
    const original = button.innerHTML;
    button.disabled = true;
    button.textContent = "掃描中…";
    const result = await send({ type: "SYNC_TUBESHELF" });
    button.innerHTML = result?.ok ? `已找到 ${result.count} 個` : "請重新整理 YouTube";
    setTimeout(() => { button.innerHTML = original; button.disabled = false; }, 1800);
  });
  document.getElementById("groups").addEventListener("click", async (event) => {
    const id = event.target.closest("[data-group]")?.dataset.group;
    if (!id) return;
    await send({ type: "OPEN_TUBESHELF", groupId: id });
    window.close();
  });

  extensionApi.onChange((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      state = Core.normalizeState(changes[STORAGE_KEY].newValue);
      render();
    }
  });

  (async function init() {
    state = Core.normalizeState(await extensionApi.getState());
    activeTab = await extensionApi.activeTab();
    render();
    renderTab();
  })();
})();
