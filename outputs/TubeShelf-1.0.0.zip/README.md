# TubeShelf｜自己的 YouTube 訂閱整理器

TubeShelf 是一個可自行側載的 Chrome／Edge 擴充套件，功能概念來自 PocketTube，但程式與介面都是獨立製作。它不需要帳號、伺服器或付費方案，群組與頻道資料只保存在瀏覽器的 `chrome.storage.local`。

## 已完成的功能

- 在 YouTube 右下角加入 TubeShelf 按鈕與滑入式側欄
- 從「所有訂閱內容」或訂閱動態頁掃描頻道
- 建立自訂群組，設定顏色與圖示
- 同一個頻道可放入多個群組
- 在 YouTube 頁面依群組篩選可見頻道／影片
- 隱藏 Shorts、隱藏已觀看影片
- 搜尋頻道、JSON 備份與還原
- 全程本機儲存，沒有分析、追蹤或雲端同步

## 安裝到 Chrome

1. 開啟 `chrome://extensions/`。
2. 打開右上角「開發人員模式」。
3. 按「載入未封裝項目」。
4. 選擇本專案的 `extension` 資料夾。
5. 重新整理已經開啟的 YouTube 分頁。

Edge 的步驟相同，管理頁網址是 `edge://extensions/`。

## 第一次使用

1. 到 [YouTube 所有訂閱內容](https://www.youtube.com/feed/channels)。
2. 點瀏覽器工具列上的 TubeShelf，再按「掃描此頁」。頻道多時請先向下捲動，讓 YouTube 載入更多頻道。
3. 點「管理群組」，新增群組並用開關把頻道放入群組。
4. 回到 YouTube，按右下角紫色 TubeShelf 按鈕即可篩選。

## 驗證

```powershell
node --test tests/shared.test.js
node --check extension/shared.js
node --check extension/content/content.js
node --check extension/popup/popup.js
node --check extension/dashboard/dashboard.js
```

## 限制

YouTube 是動態載入頁面，TubeShelf 只能收集瀏覽器當下已載入 DOM 的頻道。若訂閱很多，先在「所有訂閱內容」頁向下捲到底再掃描。YouTube 若日後改版其元件結構，掃描選擇器可能需要跟著調整。

TubeShelf 與 PocketTube、YouTube 或 Google 沒有從屬或授權關係；這是供個人使用的獨立實作。
