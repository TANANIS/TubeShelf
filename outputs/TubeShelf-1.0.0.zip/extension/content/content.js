(function () {
  "use strict";

  if (window.top !== window || document.getElementById("tubeshelf-launcher")) return;
  const Core = globalThis.TubeShelfCore;
  const STORAGE_KEY = "tubeShelfState";
  let state = Core.defaultState();
  let activeGroupId = "all";
  let scanTimer = null;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  async function readState() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    state = Core.normalizeState(result[STORAGE_KEY]);
    return state;
  }

  async function writeState(next) {
    state = Core.normalizeState(next);
    await chrome.storage.local.set({ [STORAGE_KEY]: state });
    renderGroups();
    applyFilters();
  }

  function makeShell() {
    const launcher = document.createElement("button");
    launcher.id = "tubeshelf-launcher";
    launcher.type = "button";
    launcher.title = "開啟 TubeShelf";
    launcher.setAttribute("aria-label", "開啟 TubeShelf 訂閱整理");
    launcher.innerHTML = `<svg viewBox="0 0 24 24" width="25" height="25" fill="none" aria-hidden="true"><path d="M5 5.8A2.8 2.8 0 0 1 7.8 3H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7.8A2.8 2.8 0 0 1 5 16.2V5.8Z" fill="currentColor" opacity=".3"/><path d="M4 7a2 2 0 0 1 2-2h10.5a1.5 1.5 0 0 1 0 3H8v8h8.5a1.5 1.5 0 0 1 0 3H6a2 2 0 0 1-2-2V7Z" fill="currentColor"/><path d="m11 10 5 3-5 3v-6Z" fill="currentColor"/></svg>`;

    const backdrop = document.createElement("div");
    backdrop.id = "tubeshelf-backdrop";
    const panel = document.createElement("aside");
    panel.id = "tubeshelf-panel";
    panel.setAttribute("aria-label", "TubeShelf");
    panel.innerHTML = `
      <header class="ts-panel-header">
        <div class="ts-logo"><svg viewBox="0 0 24 24" width="21" height="21" fill="white"><path d="M5 5.8A2.8 2.8 0 0 1 7.8 3H18a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H7.8A2.8 2.8 0 0 1 5 16.2V5.8Zm6 4.2v6l5-3-5-3Z"/></svg></div>
        <div class="ts-title-wrap"><h2 class="ts-title">TubeShelf</h2><div class="ts-subtitle">你的 YouTube 訂閱書架</div></div>
        <button class="ts-icon-button" data-action="close" aria-label="關閉"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="m7.4 6 4.6 4.6L16.6 6 18 7.4 13.4 12l4.6 4.6-1.4 1.4-4.6-4.6L7.4 18 6 16.6l4.6-4.6L6 7.4 7.4 6Z"/></svg></button>
      </header>
      <section class="ts-section">
        <div class="ts-section-label"><span>訂閱群組</span><span id="ts-channel-total"></span></div>
        <div class="ts-groups" id="ts-groups"></div>
      </section>
      <div class="ts-divider"></div>
      <section class="ts-section">
        <div class="ts-section-label"><span>畫面整理</span></div>
        <div class="ts-toggles">
          <label class="ts-toggle-row"><span>隱藏 Shorts</span><button class="ts-switch" data-setting="hideShorts" role="switch" aria-checked="false"></button></label>
          <label class="ts-toggle-row"><span>隱藏已觀看影片</span><button class="ts-switch" data-setting="hideWatched" role="switch" aria-checked="false"></button></label>
        </div>
      </section>
      <footer class="ts-panel-footer">
        <button class="ts-button" data-action="sync">掃描此頁頻道</button>
        <button class="ts-button ts-primary" data-action="manage">管理群組</button>
      </footer>`;

    const toast = document.createElement("div");
    toast.className = "ts-toast";
    toast.id = "ts-toast";
    document.documentElement.append(launcher, backdrop, panel, toast);

    launcher.addEventListener("click", openPanel);
    backdrop.addEventListener("click", closePanel);
    panel.addEventListener("click", onPanelClick);
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closePanel();
    });
  }

  function openPanel() {
    $("#tubeshelf-backdrop")?.classList.add("ts-open");
    $("#tubeshelf-panel")?.classList.add("ts-open");
  }

  function closePanel() {
    $("#tubeshelf-backdrop")?.classList.remove("ts-open");
    $("#tubeshelf-panel")?.classList.remove("ts-open");
  }

  function toast(message) {
    const node = $("#ts-toast");
    if (!node) return;
    node.textContent = message;
    node.classList.add("ts-show");
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => node.classList.remove("ts-show"), 2200);
  }

  function renderGroups() {
    const host = $("#ts-groups");
    if (!host) return;
    const total = Object.keys(state.channels).length;
    $("#ts-channel-total").textContent = `${total} 個頻道`;
    const all = { id: "all", name: "全部訂閱", icon: "star", color: "#7c5cff", channelIds: Object.keys(state.channels) };
    host.innerHTML = [all, ...state.groups].map((group) => `
      <button class="ts-group ${group.id === activeGroupId ? "ts-active" : ""}" data-group="${escapeHtml(group.id)}">
        <span class="ts-group-icon" style="color:${group.color};background:${group.color}20">${Core.iconSvg(group.icon, "currentColor", 18)}</span>
        <span><span class="ts-group-name">${escapeHtml(group.name)}</span><span class="ts-group-count" style="display:block">${group.id === "all" ? "目前已收集" : "已分類"}</span></span>
        <span class="ts-pill">${group.channelIds.length}</span>
      </button>`).join("");
    $$('[data-setting]').forEach((button) => button.setAttribute("aria-checked", String(Boolean(state.settings[button.dataset.setting]))));
  }

  async function onPanelClick(event) {
    const action = event.target.closest("[data-action]")?.dataset.action;
    const groupId = event.target.closest("[data-group]")?.dataset.group;
    const setting = event.target.closest("[data-setting]")?.dataset.setting;
    if (action === "close") closePanel();
    if (action === "manage") chrome.runtime.sendMessage({ type: "OPEN_DASHBOARD" });
    if (action === "sync") {
      const count = await scanChannels();
      toast(count ? `已收集 ${count} 個頻道` : "這一頁還找不到頻道，請先開啟「所有訂閱內容」");
    }
    if (groupId) {
      activeGroupId = groupId;
      renderGroups();
      applyFilters();
      toast(groupId === "all" ? "顯示全部訂閱" : `只顯示「${state.groups.find((g) => g.id === groupId)?.name || "群組"}」`);
    }
    if (setting) {
      state.settings[setting] = !state.settings[setting];
      await writeState(state);
    }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
  }

  function findChannelInCard(card) {
    const link = card.querySelector('a[href^="/@"], a[href^="/channel/"], a[href^="/c/"], a[href^="/user/"]');
    if (!link) return null;
    const id = Core.channelKey(link.href || link.getAttribute("href"));
    if (!id) return null;
    const nameNode = card.querySelector("#text, #channel-title, #channel-name, yt-formatted-string.ytd-channel-name");
    const avatar = card.querySelector("#avatar img, yt-img-shadow img")?.src || "";
    return { id, url: link.href, name: nameNode?.textContent?.trim() || link.textContent?.trim() || id, avatar };
  }

  async function scanChannels() {
    const cards = $$('ytd-channel-renderer, ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-compact-video-renderer');
    const found = new Map();
    cards.forEach((card) => {
      const channel = findChannelInCard(card);
      if (channel) found.set(channel.id, channel);
    });
    if (found.size) await writeState(Core.upsertChannels(state, [...found.values()]));
    return found.size;
  }

  function applyFilters() {
    const group = activeGroupId === "all" ? null : state.groups.find((item) => item.id === activeGroupId);
    const allowed = group ? new Set(group.channelIds) : null;
    const cards = $$('ytd-rich-item-renderer, ytd-video-renderer, ytd-grid-video-renderer, ytd-channel-renderer, ytd-compact-video-renderer, ytd-rich-section-renderer');
    for (const card of cards) {
      let hidden = false;
      const channel = findChannelInCard(card);
      if (allowed && (!channel || !allowed.has(channel.id))) hidden = true;
      if (state.settings.hideShorts) {
        const shortsLink = card.querySelector('a[href^="/shorts/"]');
        if (shortsLink || card.tagName.toLowerCase() === "ytd-rich-section-renderer") hidden = true;
      }
      if (state.settings.hideWatched) {
        const progress = card.querySelector("#progress, ytd-thumbnail-overlay-resume-playback-renderer");
        if (progress) hidden = true;
      }
      card.classList.toggle("tubeshelf-hidden", hidden);
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "OPEN_TUBESHELF") {
      if (message.groupId === "all" || state.groups.some((group) => group.id === message.groupId)) activeGroupId = message.groupId;
      renderGroups();
      applyFilters();
      openPanel();
      sendResponse({ ok: true });
    }
    if (message?.type === "SYNC_TUBESHELF") {
      scanChannels().then((count) => sendResponse({ ok: true, count }));
      return true;
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[STORAGE_KEY]) {
      state = Core.normalizeState(changes[STORAGE_KEY].newValue);
      renderGroups();
      applyFilters();
    }
  });

  const observer = new MutationObserver(() => {
    clearTimeout(scanTimer);
    scanTimer = setTimeout(applyFilters, 250);
  });

  async function init() {
    makeShell();
    await readState();
    renderGroups();
    applyFilters();
    observer.observe(document.body, { childList: true, subtree: true });
  }

  init();
})();
