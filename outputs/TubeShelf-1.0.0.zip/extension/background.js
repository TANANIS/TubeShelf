chrome.runtime.onInstalled.addListener(async () => {
  const saved = await chrome.storage.local.get("tubeShelfState");
  if (!saved.tubeShelfState) {
    await chrome.storage.local.set({
      tubeShelfState: {
        version: 1,
        groups: [
          { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: [] },
          { id: "relax", name: "放鬆", icon: "sparkles", color: "#ff6b8a", channelIds: [] }
        ],
        channels: {},
        settings: { hideShorts: false, hideWatched: false, compactMode: false }
      }
    });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "OPEN_DASHBOARD") {
    chrome.runtime.openOptionsPage();
    sendResponse({ ok: true });
  }
});
