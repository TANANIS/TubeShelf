(function (root, factory) {
  const api = factory();
  root.TubeShelfCore = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const VERSION = 2;
  const DEFAULT_GROUPS = [
    { id: "learning", name: "學習", icon: "book", color: "#7c5cff", channelIds: [] },
    { id: "relax", name: "放鬆", icon: "sparkles", color: "#ff6b8a", channelIds: [] }
  ];

  const ICONS = {
    book: "M5 4.8A2.8 2.8 0 0 1 7.8 2H11v15H7.8A2.8 2.8 0 0 0 5 19.8V4.8Zm14 0A2.8 2.8 0 0 0 16.2 2H13v15h3.2a2.8 2.8 0 0 1 2.8 2.8V4.8Z",
    sparkles: "m12 2 1.1 3.4a5.5 5.5 0 0 0 3.5 3.5L20 10l-3.4 1.1a5.5 5.5 0 0 0-3.5 3.5L12 18l-1.1-3.4a5.5 5.5 0 0 0-3.5-3.5L4 10l3.4-1.1a5.5 5.5 0 0 0 3.5-3.5L12 2Zm7 14 .6 1.7a2.8 2.8 0 0 0 1.7 1.7l1.7.6-1.7.6a2.8 2.8 0 0 0-1.7 1.7L19 24l-.6-1.7a2.8 2.8 0 0 0-1.7-1.7L15 20l1.7-.6a2.8 2.8 0 0 0 1.7-1.7L19 16Z",
    game: "M8 7h8a6 6 0 0 1 5.7 7.9l-1.1 3.4a2.4 2.4 0 0 1-4.1.8L14.8 17H9.2l-1.7 2.1a2.4 2.4 0 0 1-4.1-.8l-1.1-3.4A6 6 0 0 1 8 7Zm0 3v2H6v2h2v2h2v-2h2v-2h-2v-2H8Zm8.5 2a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Zm2.5 3a1.2 1.2 0 1 0 0-2.4A1.2 1.2 0 0 0 19 15Z",
    music: "M18 3v13.1A4 4 0 1 1 16 13V7l-7 2v9.1A4 4 0 1 1 7 15V6l11-3Z",
    code: "m9 6-6 6 6 6 1.5-1.5L6 12l4.5-4.5L9 6Zm6 0-1.5 1.5L18 12l-4.5 4.5L15 18l6-6-6-6Z",
    star: "m12 2.8 2.8 5.7 6.3.9-4.6 4.5 1.1 6.3-5.6-3-5.6 3 1.1-6.3-4.6-4.5 6.3-.9L12 2.8Z"
  };

  const AUTO_GROUPS = [
    { id: "games", name: "遊戲", icon: "game", color: "#2dbd9b", keywords: ["遊戲", "實況", "攻略", "電競", "game", "gaming", "gameplay", "gamer", "steam", "nintendo", "playstation", "xbox", "minecraft", "godot", "unity", "osu"] },
    { id: "music", name: "音樂", icon: "music", color: "#ff6b8a", keywords: ["音樂", "歌曲", "歌手", "翻唱", "演奏", "鋼琴", "吉他", "music", "song", "singer", "cover", "concert", "piano", "guitar", "jazz", "lofi"] },
    { id: "technology", name: "科技", icon: "code", color: "#4a91ff", keywords: ["科技", "程式", "軟體", "硬體", "電腦", "開發者", "人工智慧", "tech", "technology", "programming", "coding", "developer", "software", "hardware", "computer", "windows", "linux", "javascript", "python", "ai"] },
    { id: "learning", name: "學習", icon: "book", color: "#7c5cff", keywords: ["學習", "知識", "科普", "教學", "歷史", "數學", "物理", "化學", "語言", "science", "education", "educational", "tutorial", "history", "math", "physics", "chemistry", "documentary", "explained"] },
    { id: "news", name: "新聞與時事", icon: "star", color: "#f0a44b", keywords: ["新聞", "時事", "政治", "國際", "財經", "報導", "評論", "news", "politics", "current affairs", "finance", "economy", "reporter", "journalism"] },
    { id: "art", name: "藝術與動畫", icon: "sparkles", color: "#bc6fe8", keywords: ["藝術", "繪畫", "插畫", "動畫", "設計", "攝影", "漫畫", "art", "artist", "drawing", "illustration", "animation", "anime", "design", "photography"] },
    { id: "food", name: "美食", icon: "sparkles", color: "#ff8a5c", keywords: ["美食", "料理", "食譜", "烹飪", "餐廳", "甜點", "food", "cooking", "recipe", "restaurant", "kitchen", "chef", "dessert"] },
    { id: "life", name: "生活", icon: "sparkles", color: "#51c58a", keywords: ["生活", "日常", "旅行", "旅遊", "開箱", "健身", "健康", "vlog", "lifestyle", "travel", "unboxing", "fitness", "health", "daily"] }
  ];

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function defaultState() {
    return {
      version: VERSION,
      groups: clone(DEFAULT_GROUPS),
      channels: {},
      settings: { hideShorts: false, hideWatched: false, compactMode: false }
    };
  }

  function normalizeState(input) {
    const base = defaultState();
    if (!input || typeof input !== "object") return base;
    const channels = input.channels && typeof input.channels === "object" ? input.channels : {};
    const groups = Array.isArray(input.groups)
      ? input.groups
          .filter((group) => group && typeof group.name === "string")
          .map((group, index) => ({
            id: String(group.id || `group-${index + 1}`),
            name: group.name.trim().slice(0, 40) || `群組 ${index + 1}`,
            icon: ICONS[group.icon] ? group.icon : "star",
            color: /^#[0-9a-f]{6}$/i.test(group.color || "") ? group.color : "#7c5cff",
            channelIds: Array.isArray(group.channelIds)
              ? [...new Set(group.channelIds.map(String).filter((id) => channels[id]))]
              : []
          }))
      : base.groups;
    return {
      version: VERSION,
      groups,
      channels,
      settings: { ...base.settings, ...(input.settings || {}) }
    };
  }

  function channelKey(url) {
    if (!url || typeof url !== "string") return "";
    try {
      const parsed = new URL(url, "https://www.youtube.com");
      const path = parsed.pathname.replace(/\/$/, "");
      if (!/^\/(channel\/|@|c\/|user\/)/i.test(path)) return "";
      const parts = path.split("/").filter(Boolean);
      if (!parts.length) return "";
      const stableParts = parts[0].startsWith("@") ? [parts[0]] : parts.slice(0, 2);
      return `/${stableParts.join("/")}`.toLowerCase();
    } catch (_error) {
      return "";
    }
  }

  function createId(name, usedIds) {
    const base = String(name || "group")
      .normalize("NFKD")
      .toLowerCase()
      .replace(/[^a-z0-9\u4e00-\u9fff]+/g, "-")
      .replace(/^-|-$/g, "") || "group";
    let id = base;
    let suffix = 2;
    while (usedIds.includes(id)) id = `${base}-${suffix++}`;
    return id;
  }

  function upsertChannels(state, incoming) {
    const next = normalizeState(state);
    for (const channel of incoming || []) {
      const id = channelKey(channel.url || channel.id);
      if (!id) continue;
      next.channels[id] = {
        id,
        name: String(channel.name || next.channels[id]?.name || id).trim().slice(0, 120),
        url: `https://www.youtube.com${id}`,
        avatar: typeof channel.avatar === "string" ? channel.avatar : next.channels[id]?.avatar || "",
        seenAt: Number(channel.seenAt) || Date.now(),
        description: String(channel.description || next.channels[id]?.description || "").trim().slice(0, 2000),
        recentTitles: Array.isArray(channel.recentTitles) ? channel.recentTitles.map(String).slice(0, 20) : next.channels[id]?.recentTitles || [],
        profiledAt: Number(channel.profiledAt) || Number(next.channels[id]?.profiledAt) || 0
      };
    }
    return next;
  }

  function replaceChannels(state, incoming) {
    const current = normalizeState(state);
    const channels = {};
    for (const channel of incoming || []) {
      const id = channelKey(channel.url || channel.id);
      if (!id) continue;
      channels[id] = {
        id,
        name: String(channel.name || current.channels[id]?.name || id).trim().slice(0, 120),
        url: `https://www.youtube.com${id}`,
        avatar: typeof channel.avatar === "string" ? channel.avatar : current.channels[id]?.avatar || "",
        seenAt: Number(channel.seenAt) || Date.now(),
        description: String(channel.description || current.channels[id]?.description || "").trim().slice(0, 2000),
        recentTitles: Array.isArray(channel.recentTitles) ? channel.recentTitles.map(String).slice(0, 20) : current.channels[id]?.recentTitles || [],
        profiledAt: Number(channel.profiledAt) || Number(current.channels[id]?.profiledAt) || 0
      };
    }
    return normalizeState({
      ...current,
      channels,
      groups: current.groups.map((group) => ({ ...group, channelIds: group.channelIds.filter((id) => channels[id]) }))
    });
  }

  function groupForChannel(state, id) {
    return normalizeState(state).groups.filter((group) => group.channelIds.includes(id));
  }

  function keywordMatches(text, keyword) {
    const source = String(text || "").toLowerCase();
    const needle = String(keyword || "").toLowerCase();
    if (!needle) return false;
    if (/^[a-z0-9]+$/.test(needle) && needle.length <= 3) {
      const escaped = needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`, "i").test(source);
    }
    return source.includes(needle);
  }

  function classifyChannel(channel) {
    const name = String(channel?.name || "");
    const description = String(channel?.description || "");
    const titles = Array.isArray(channel?.recentTitles) ? channel.recentTitles.join(" ") : "";
    const ranked = AUTO_GROUPS.map((group) => {
      const reasons = [];
      let score = 0;
      for (const keyword of group.keywords) {
        let matched = false;
        if (keywordMatches(name, keyword)) { score += 4; matched = true; }
        if (keywordMatches(description, keyword)) { score += 2; matched = true; }
        if (keywordMatches(titles, keyword)) { score += 1; matched = true; }
        if (matched && reasons.length < 3) reasons.push(keyword);
      }
      return { groupId: group.id, name: group.name, icon: group.icon, color: group.color, score, reasons };
    }).sort((a, b) => b.score - a.score);
    const best = ranked[0];
    if (!best || best.score < 3 || (ranked[1] && best.score === ranked[1].score)) return null;
    return { ...best, confidence: best.score >= 8 ? "high" : "medium" };
  }

  function buildAutoGroupSuggestions(state) {
    const current = normalizeState(state);
    const filed = new Set(current.groups.flatMap((group) => group.channelIds));
    const suggestions = new Map();
    const uncertain = [];
    for (const channel of Object.values(current.channels)) {
      if (filed.has(channel.id)) continue;
      const result = classifyChannel(channel);
      if (!result) { uncertain.push(channel.id); continue; }
      if (!suggestions.has(result.groupId)) suggestions.set(result.groupId, { ...result, channelIds: [], channels: [] });
      const target = suggestions.get(result.groupId);
      target.channelIds.push(channel.id);
      target.channels.push({ id: channel.id, name: channel.name, reasons: result.reasons, confidence: result.confidence });
    }
    return { groups: [...suggestions.values()], uncertain };
  }

  function applyAutoGroupSuggestions(state, suggestionGroups) {
    const next = normalizeState(state);
    for (const suggestion of suggestionGroups || []) {
      const validIds = [...new Set((suggestion.channelIds || []).filter((id) => next.channels[id]))];
      if (!validIds.length) continue;
      let group = next.groups.find((item) => item.name.trim().toLowerCase() === String(suggestion.name || "").trim().toLowerCase());
      if (!group) {
        group = {
          id: createId(suggestion.name || suggestion.groupId, next.groups.map((item) => item.id)),
          name: String(suggestion.name || "自動分類").trim().slice(0, 40),
          icon: ICONS[suggestion.icon] ? suggestion.icon : "star",
          color: /^#[0-9a-f]{6}$/i.test(suggestion.color || "") ? suggestion.color : "#7c5cff",
          channelIds: []
        };
        next.groups.push(group);
      }
      group.channelIds = [...new Set([...group.channelIds, ...validIds])];
    }
    return normalizeState(next);
  }

  function iconSvg(name, color, size) {
    const path = ICONS[name] || ICONS.star;
    const px = Number(size) || 20;
    return `<svg aria-hidden="true" viewBox="0 0 24 24" width="${px}" height="${px}" fill="${color || "currentColor"}"><path d="${path}"/></svg>`;
  }

  return {
    VERSION,
    ICONS,
    AUTO_GROUPS,
    DEFAULT_GROUPS,
    defaultState,
    normalizeState,
    channelKey,
    createId,
    upsertChannels,
    replaceChannels,
    groupForChannel,
    classifyChannel,
    buildAutoGroupSuggestions,
    applyAutoGroupSuggestions,
    iconSvg
  };
});
